"TODO"

import sys



from user.authentication import authenticate_user
from transactions.journal import receive_income, pay_expense
from banking import recon
# from banking.reconciliation import do_reconciliation
# from banking.fvb.reconciliation import do_reconciliation 
# from banking.ubsa.reconciliation import do_reconciliation
# from banking.online.reconciliation import do_reconciliation

if len(sys.argv) > 1:
    for i in range (1, len(sys.argv)):
        print (sys.argv[i])

if __name__ == "__main__":
    authenticate_user()
    receive_income(100)
    pay_expense(100)
    recon.do_reconciliation()
