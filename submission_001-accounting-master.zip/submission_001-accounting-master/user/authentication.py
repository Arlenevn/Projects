  
  
  
print ("[Module] User Authentication loaded.")



def authenticate_user():

   print ("Authenticating User")
        
     
    

