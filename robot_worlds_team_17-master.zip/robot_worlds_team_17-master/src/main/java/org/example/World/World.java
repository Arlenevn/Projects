package org.example.World;

import com.google.gson.Gson;
import org.example.Robot;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.util.*;

public class World implements WorldInterface {
    private static int[] BOTTOM_RIGHT;
    private static int[] TOP_LEFT;
    private static final List<Obstacle> obstacleList = new ArrayList<>();
    private static final Map<String, Integer> config = new HashMap<>();
    private static final ArrayList<Robot> robotList = new ArrayList<>();

    /**
     * World constructor; reads config file and populates config map with read values
     */
    public World() {
        Gson gson = new Gson(); //Gson googles package that interacts with Json.
        try {
            File file = new File("./configs/config.json");//Declare config file
            Reader reader = Files.newBufferedReader(file.toPath()); //get path to declared config file
            Map<?, ?> temp = gson.fromJson(reader, Map.class);//Read JSON from config file, store in anonymous map
            for (Map.Entry<?, ?> entry : temp.entrySet()) { //Iterating through the map.
                double value = (double) entry.getValue(); //cast each value to a primitive double
                config.put((String) entry.getKey(), (int) value); //populate config map with value cast as int
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Robot> getRobotList() { return robotList; }

    /**
     * Adds a robot to the list of robots populating the World.
     */
    public static void addRobot(Robot robot) { robotList.add(robot); }

    public int getConfigValue(String key) { return config.get(key); }

    public List<Obstacle> getList(){ return obstacleList; }

    public String handleCommand(Robot robot, String command) {
        Commands commands = new Commands();
        String[] splitCommand = command.toLowerCase().split(" "); //Split and lower case incoming command.
        String returnValue; //Return value to be modified as code block runs
        switch (splitCommand[0]) { //which command is being called
            case "forward":
                try {
                    returnValue = commands.Forward(robot, Integer.parseInt(splitCommand[1])); //convert String step count to int
                    return returnValue;
                } catch (RuntimeException e) {
                    return "Invalid";
                }
            case "back":
                try {
                    returnValue = commands.Back(robot, Integer.parseInt(splitCommand[1]));
                    return returnValue;
                } catch (RuntimeException e) {
                    return "Invalid";
                }
            case "right":
                commands.turnRight(robot);
                return "Success";
            case "left":
                commands.turnLeft(robot);
                return "Success";
            case "quit":
                //quit the program
                return "quit";
            default:
                //Unknown command
                return "Unknown";
        }
    }
    public String checkCollision(Robot robot, String direction, int destinationX, int destinationY) {
        List<Integer> position = robot.getPosition();
        for (Obstacle obst : getList()){ //Iterate through obstacle list
            switch (direction) {
                case "North" :
                    //Check robot's X is within the X and X+4 of current obstacle
                    if ((position.get(0) >= obst.getX()) && (position.get(0) <= obst.getX() + 4)) {
                        //Check obstacle Y value is in between current Y value and destination's Y value
                        if ((obst.getY() <= destinationY) && (obst.getY() > position.get(1))) {
                            return "Obstacle";
                        }
                    }
                    //Check if destination is in bounds
                    if ((destinationY >= TOP_LEFT[1]) || (destinationY <= BOTTOM_RIGHT[1])) { return "Edge"; }
                    break;
                case "East" :
                    //Check robot's Y is within the Y and Y+4 of current obstacle
                    if ((position.get(1) >= obst.getY()) && (position.get(1) <= obst.getY() + 4)) {
                        //Check obstacle X value is in between current X value and destination's X value
                        if ((obst.getX() <= destinationX) && (obst.getX() > position.get(0))) {
                            return "Obstacle";
                        }
                    }
                    //Check if destination is in bounds
                    if ((destinationX <= TOP_LEFT[0]) || (destinationX >= BOTTOM_RIGHT[0])) { return "Edge"; }
                    break;
                case "South" :
                    //Check robot's X is within the X and X+4 of current obstacle
                    if ((position.get(0) >= obst.getX()) && (position.get(0) <= obst.getX() + 4)) {
                        //Check obstacle Y value is in between current Y value and destination's Y value
                        if ((obst.getY() + 4 >= destinationY) && (obst.getY() < position.get(1))) {
                            return "Obstacle";
                        }
                    }
                    //Check if destination is in bounds
                    if ((destinationY >= TOP_LEFT[1]) || (destinationY <= BOTTOM_RIGHT[1])) { return "Edge"; }
                    break;
                case "West" :
                    //Check robot's Y is within the Y and Y+4 of current obstacle
                    if ((position.get(1) >= obst.getY()) && (position.get(1) <= obst.getY() + 4)) {
                        //Check obstacle X value is in between current X value and destination's X value
                        if ((obst.getX() + 4 >= destinationX) && (obst.getX() < position.get(0))) {
                            return "Obstacle";
                        }
                    }
                    //Check if destination is in bounds
                    if ((destinationX <= TOP_LEFT[0]) || (destinationX >= BOTTOM_RIGHT[0])) { return "Edge"; }
            }
        }
        //Run Robot Collision check
        if (checkRobotCollision(robot, direction, destinationX, destinationY).equals("Robot")) {
            return "Robot";
        }
        return "Success";
    }

    public String checkRobotCollision(Robot robot, String direction, int destinationX, int destinationY) {
        List<Integer> position = robot.getPosition();
        for (Robot entry : getRobotList()) { //Iterate through list of Robots in world
            List<Integer> enemyPos = entry.getPosition(); //position of current robot
            switch (direction) {
                case "North":
                    //check for collision
                    if ((position.get(0) >= enemyPos.get(0)) && (position.get(0) <= enemyPos.get(0) + 4)) {
                        if ((enemyPos.get(1) <= destinationY) && (enemyPos.get(1) > position.get(1))) {
                            return "Robot";
                        }
                    }
                    break;
                case "East" :
                    //check for collision
                    if ((position.get(1) >= enemyPos.get(1)) && (position.get(1) <= enemyPos.get(1) + 4)) {
                        if ((enemyPos.get(0) <= destinationX) && (enemyPos.get(0) > position.get(0))) {
                            return "Robot";
                        }
                    }
                    break;
                case "South" :
                    //check for collision
                    if ((position.get(0) >= enemyPos.get(0)) && (position.get(0) <= enemyPos.get(0) + 4)) {
                        if ((enemyPos.get(1) + 4 >= destinationY) && (enemyPos.get(1) < position.get(1))) {
                            return "Robot";
                        }
                    }
                    break;
                case "West" :
                    //check for collision
                    if ((position.get(1) >= enemyPos.get(1)) && (position.get(1) <= enemyPos.get(1) + 4)) {
                        if ((enemyPos.get(0) + 4 >= destinationX) && (enemyPos.get(0) < position.get(0))) {
                            return "Robot";
                        }
                    }
            }
        }
        return "Success";
    }

    /**
     * Populate internal variables and generate obstacles in world.
     */
    public static void generateWorld(){
        int obstacleCount = config.get("ObstacleCount");
        int width = config.get("WorldWidth");
        int height = config.get("WorldHeight");
        TOP_LEFT = new int[]{-width / 2, height / 2};
        BOTTOM_RIGHT = new int[]{width/2, -height/2};
        Random random = new Random();

        //Obstacles generated in the code
        for (int i = 0; i < obstacleCount; i++) {
            //Randomly generating obstacles as per TR5.
            int ranX = random.nextInt(width) - (width / 2);
            int ranY = random.nextInt(height) - (height / 2);
            obstacleList.add(new Obstacle(ranX, ranY));
        }

    }
}