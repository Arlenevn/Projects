package org.example.World;

public class Obstacle {
    int x;
    int y;
    /**
     * Constructs an obstacle object with the specified x and y coordinates.
     *
     * @param x The x-coordinate of the obstacle.
     * @param y The y-coordinate of the obstacle.
     */
    public Obstacle(int x, int y) {
        this.x = x;
        this.y = y;
    }
    /**
     * Returns the x-coordinate of the obstacle.
     *
     * @return The x-coordinate of the obstacle.
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the y-coordinate of the obstacle.
     *
     * @return The y-coordinate of the obstacle.
     */
    public int getY() {
        return y;
    }

    /**
     * Returns a string representation of the obstacle object.
     *
     * @return A string representation of the obstacle object.
     */
    public String toString(){
        return "["+x+","+y+"]";
    }
}