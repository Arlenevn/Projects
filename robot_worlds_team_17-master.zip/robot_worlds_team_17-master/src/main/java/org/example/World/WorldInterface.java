package org.example.World;

import org.example.Robot;

import java.util.ArrayList;
import java.util.List;

public interface WorldInterface {
    /**
     @return ArrayList
     */
    ArrayList<Robot> getRobotList();

    /**
     * Fetches the value associated with a given key from config.
     * @param key String
     * @return Config value as an Int
     */
    int getConfigValue(String key);

    /**
     * Fetches obstacles in the current instance of World.
     * @return List of Obstacle objects representing obstacles.
     */
    List<Obstacle> getList();

    /**
     * Execute given command upon given robot, and determine the outcome of the command.
     * Possible outcomes are:
     * "Success", if command is executed without issue.
     * "Obstacle", if an obstacle hindered command execution.
     * "Edge", if command attempted to take robot outside world borders.
     * "Robot", if a robot hindered command execution.
     * "Quit", if command is "quit".
     * "Unknown", if command is not recognized.
     * "Invalid", if an unforeseen error has terminated command execution.
     * @param robot Robot Object
     * @param command String
     * @return String
     *
     * @throws RuntimeException
     */
    String handleCommand(Robot robot, String command);

    /**
     * Check robot's collision with obstacles.
     * Can return the following Strings:
     * "Robot", if collision with a robot has been detected.
     * "Success", if no collisions are detected.
     *
     * @param robot The robot whose collision is being checked.
     * @param direction Direction the robot in question is facing.
     * @param destinationX X co-ordinate of destination point.
     * @param destinationY Y co-ordinate of destination point.
     * @return String
     */
    String checkRobotCollision(Robot robot, String direction, int destinationX, int destinationY);

    /**
     * Check robot's collision with obstacles, robots and the edge.
     * Can return the following Strings:
     *  "Obstacle", if an obstacle hindered command execution.
     *  "Edge", if command attempted to take robot outside world borders.
     *  "Robot", if a robot hindered command execution.
     * @param robot The robot whose collision is being checked.
     * @param direction Direction the robot in question is facing
     * @param destinationX X co-ordinate of destination point
     * @param destinationY Y  co-ordinate of destination point
     * @return String
     */
    String checkCollision(Robot robot, String direction, int destinationX, int destinationY);
}
