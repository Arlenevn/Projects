package org.example.World;

import org.example.Robot;

import java.util.List;


public class Commands {
    World world = new World();
    public String Forward(Robot robot, int steps) {
        List<Integer> position = robot.getPosition();
        int newX = position.get(0);
        int newY = position.get(1);
        String collisionCheck;
        switch (robot.getDirection()) {
            case "North":
                collisionCheck = world.checkCollision(robot, "North", newX, newY + steps);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX, newY + steps);
                }
                return collisionCheck;
            case "East":
                collisionCheck = world.checkCollision(robot, "East", newX + steps, newY);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX + steps, newY);
                }
                return collisionCheck;
            case "South":
                collisionCheck = world.checkCollision(robot, "South", newX, newY - steps);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX, newY - steps);
                }
                return collisionCheck;
            case "West":
                collisionCheck = world.checkCollision(robot, "West", newX - steps, newY);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX - steps, newY);
                }
                return collisionCheck;
        }
        return "Fail";
    }
    public String Back(Robot robot, int steps) {
        List<Integer> position = robot.getPosition();
        int newX = position.get(0);
        int newY = position.get(1);
        String collisionCheck;
        switch (robot.getDirection()) {
            case "North":
                collisionCheck = world.checkCollision(robot, "South", newX, newY - steps);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX, newY - steps);
                }
                return collisionCheck;
            case "East":
                collisionCheck = world.checkCollision(robot, "West", newX - steps, newY);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX - steps, newY);
                }
                return collisionCheck;
            case "South":
                collisionCheck = world.checkCollision(robot, "North", newX, newY - steps);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX, newY + steps);
                }
                return collisionCheck;
            case "West":
                collisionCheck = world.checkCollision(robot, "East", newX - steps, newY);
                if (collisionCheck.equals("Success")) {
                    robot.updatePosition(newX + steps, newY);
                }
                return collisionCheck;
        }
        return "Fail";
    }
    public void turnRight(Robot robot) {
        String direction = robot.getDirection();
        switch (direction) {
            case "North":
                robot.updateDirection("East");
                break;
            case "East":
                robot.updateDirection("South");
                break;
            case "South":
                robot.updateDirection("West");
                break;
            case "West":
                robot.updateDirection("North");
                break;
        }
    }
    public void turnLeft(Robot robot) {
        String direction = robot.getDirection();
        switch (direction) {
            case "North":
                robot.updateDirection("West");
                break;
            case "West":
                robot.updateDirection("South");
                break;
            case "South":
                robot.updateDirection("East");
                break;
            case "East":
                robot.updateDirection("North");
                break;
        }
    }
}