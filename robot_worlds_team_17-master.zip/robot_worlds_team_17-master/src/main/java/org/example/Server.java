package org.example;

import com.diogonunes.jcolor.Attribute;
import com.google.gson.*;
import org.example.World.World;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

import static com.diogonunes.jcolor.Ansi.colorize;

public class Server {
    private final ServerSocket serverSocket;
    private boolean running;

    private final List<String> robotsConnected = new ArrayList<>();

    private final Scanner scanner;

    public Server(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        System.out.println("Server started on port " + port);
        scanner = new Scanner(System.in);
    }

    /**
     *
     * Accepts clients to connect to server while waiting for server commands
     */
    public void start() throws IOException{
        running = true;


        // Run the first while loop in a separate thread
        Thread connectionThread = new Thread(() -> {
            //First while loop is accepting clients into the server.
            while (running) {
                try {
                    Socket socket = serverSocket.accept();
                    System.out.println("Client connected: " + socket);
                    String clientName = socket.getInetAddress().getHostName();
                    robotsConnected.add(clientName);
                    System.out.println(robotsConnected.get(robotsConnected.size() - 1) + " connected to the server.");// prints out the client name/IP

                    ClientHandler clientHandler = new ClientHandler(socket);
                    new Thread(clientHandler).start(); // creates a new thread for each connection
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        connectionThread.start();
        // Run the second while loop in the main thread
        while (running) {
            System.out.print("Enter a command: \n");
            String response = scanner.nextLine();
            response = response.toLowerCase();
            System.out.println("Entered response: "+ response);
            ServerCommands.Commands(response, connectionThread);

            if (Objects.equals(response.toLowerCase(), "robots")){
                ServerCommands.Robots(new World());
                }
        }
    }

    //Accepts input from the client and outputs a response.
    static class ClientHandler extends Thread {
        private final Socket socket;
        private final ObjectInputStream inputStream;
        private final ObjectOutputStream outputStream;

        public ClientHandler(Socket socket) throws IOException {
            this.socket = socket;
            this.inputStream = new ObjectInputStream(socket.getInputStream());
            this.outputStream = new ObjectOutputStream(socket.getOutputStream());
        }

        /**
         * Accepts client commands and handles them appropriately
         */
        @Override
        public void run() {

            //Takes users input and sends it to World. Which then handles the command.
            try {
                boolean launched = false;
                Robot robot = null;
                World world = new World();

                Random random = new Random();
                while(!launched) {
                    String message1 = (String) inputStream.readObject();
                    System.out.println("Received message from client: " + message1);
                    System.out.println("Enter a command: \n");

                    // parse the JSON string
                    JsonElement jsonElement = JsonParser.parseString(message1);
                    JsonObject message = jsonElement.getAsJsonObject();

                    // get the values
                    String command = message.get("command").getAsString();
                    command = command.toLowerCase();
                    String name = message.get("robot").getAsString();
                    List<Integer> position = new ArrayList<>();

                    // launches the robot into the world
                    if (command.equals("launch")) {
                        position.add(random.nextInt(201) - 100);
                        position.add(random.nextInt(201) - 100);
                        robot = new Robot(name, position);
                        JsonArray type = message.get("arguments").getAsJsonArray();
                        robot.configRobots(type.get(0).getAsString());
                        Gson gson = new Gson(); //Gson googles package that interacts with Json.
                        try {
                            // Read the JSON file
                            BufferedReader bufferedReader = new BufferedReader(new FileReader("./configs/robot_config.json"));
                            JsonElement jsonElement1 = gson.fromJson(bufferedReader, JsonElement.class);
                            JsonObject jsonObject = jsonElement1.getAsJsonObject();

                            // Get the "type" object
                            JsonObject robotObject = jsonObject.getAsJsonObject("robots").getAsJsonObject(type.get(0).getAsString());

                            // Extract the maxAmmo value for chosen type
                            int maxAmmo = robotObject.get("maxAmmo").getAsInt();
                            int shields = robotObject.get("maxShieldValue").getAsInt();
                            int visibility = robotObject.get("visibility").getAsInt();

                            // set the correct info according to type
                            robot.setMaxAmmo(maxAmmo);
                            robot.setAmmo(true);
                            robot.setMaxShieldValue(shields);
                            robot.setShieldValue(true);
                            robot.setVisibility(visibility);
                            robot.setRobotType(type.get(0).getAsString());


                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        World.addRobot(robot);
                        String response = "You are now in the world";
                        String response2 = robot.getStatus()+robot.getAmmo()+robot.getShieldValue()+robot.getPosition()+robot.getDirection()+"}";

                        String jsonString = gson.toJson(getJsonObject(response, response2));
                        outputStream.writeObject(jsonString);
                        launched = true;
                    }
                    else{
                        String response = "Not a valid command, you are not launched into the world.";

                        String response2 = "Not in world";
                        Gson gson = new Gson();

                        String jsonString = gson.toJson(getJsonObject(response, response2));
                        outputStream.writeObject(jsonString);
                        outputStream.flush();
                    }
                }
                // when launched wait for and handle client commands
                while (true) {
                    String response;
                    String newMessage1 = (String) inputStream.readObject();
                    System.out.println("Client: " + newMessage1);

                    // parse the JSON string
                    JsonElement jsonElement1 = JsonParser.parseString(newMessage1);
                    JsonObject newMessage = jsonElement1.getAsJsonObject();

                    // get the values
                    String command2 = newMessage.get("command").getAsString();
                    command2 = command2.toLowerCase();
                    if (robot.getStatus().equals("Dead")) {
                        response = colorize("You are Dead", Attribute.RED_TEXT());
                        String response2 = robot.getStatus()+robot.getAmmo()+robot.getShieldValue()+robot.getPosition()+robot.getDirection()+"}";
                        Gson gson = new Gson();

                        String jsonString = gson.toJson(getJsonObject(response, response2));
                        outputStream.writeObject(jsonString);
                        outputStream.flush();
                    } else {
                        switch (command2) {
                            case "look":
                                response = LookCommand.Look(robot, world);
                                break;
                            case "state":
                                response = "\n" + "     position: " + robot.getPosition() + "\n" +
                                        "     direction: " + robot.getDirection() + "\n" +
                                        "     shield: " + robot.getShieldValue() + "\n" +
                                        "     shots: " + robot.getAmmo() + "\n" +
                                        "     status: " + robot.getStatus();
                                break;
                            case "orientation":
                                response = "The robot is facing: " + robot.getDirection();
                                break;
                            case "reload":
                                robot.setStatus(command2);
                                try {
                                    Thread.sleep(world.getConfigValue("ReloadSpeed") * 1000L);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                robot.setAmmo(true);
                                response = "Successfully reloaded, current ammo: " + robot.getAmmo();
                                robot.setStatus("Ready");
                                break;
                            case "repair":
                                robot.setStatus(command2);
                                try {
                                    Thread.sleep(world.getConfigValue("ShieldRepairTime") * 1000L);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                robot.setShieldValue(true);
                                response = "Successfully repaired, current shields: " + robot.getShieldValue();
                                robot.setStatus("Ready");
                                break;
                            case "fire":
                                if (robot.getAmmo() > 0) {
                                    robot.setAmmo(false);
                                    response = fireCommand.fire(robot, world);
                                } else {
                                    response = "No ammo";
                                }
                                break;
                            default:
                                String i = world.handleCommand(robot, command2);
                                List<Integer> pos = robot.getPosition();
                                switch (i) {
                                    case "Success":
                                        if(command2.equals("left") || command2.equals("right")){
                                            response = "You turned " + command2 +"! You are now facing " + robot.getDirection()+".";
                                        }
                                        else {
                                            response = "You moved " + command2 + " successfully! You are currently at " + pos.get(0) + " ," + pos.get(1);
                                        }
                                        break;
                                    case "Edge":
                                        response = "You can't go outside the zone...";
                                        break;
                                    case "Obstacle":
                                        response = "An obstacle blocks the way...";
                                        break;
                                    case "Robot":
                                        response = "Oi, there's a robot in your way!";
                                        break;
                                    case "Invalid":
                                        response = "Please enter a valid step count for command.";
                                        break;
                                    case "Unknown":
                                        response = "Command not recognized, please check input and try again.";
                                        break;
                                    case "quit":
                                        response = "Shutting down...";
                                        break;
                                    default:
                                        response = "Error";
                                        break;
                                }
                                break;
                        }
                        String response2 = robot.getStatus()+robot.getAmmo()+robot.getShieldValue()+robot.getPosition()+robot.getDirection()+"}";
                        Gson gson = new Gson();

                        String jsonString = gson.toJson(getJsonObject(response, response2));
                        outputStream.writeObject(jsonString);
                        outputStream.flush();

                        System.out.print("Enter a command: \n");
                        if (command2.equals("quit")) {
                            break;
                        }
                    }
                }


                    inputStream.close();
                    outputStream.close();
                    socket.close();
                    System.out.println("Client disconnected: " + socket);

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
    public static Object getJsonObject(String printOut, String notPrint) {
//        String robot = "name of the robot";
//        String command = "name of the command";

        // create an object to hold the JSON fields
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("print", printOut);
        jsonObject.addProperty("State", notPrint);
        JsonArray argumentsArray = new JsonArray();

        jsonObject.add("arguments", argumentsArray);

        return jsonObject;
    }
    //This starts the server program.
    public static void main(String[] args) throws IOException{
        Server server = new Server(5000);
        new World();
        World.generateWorld();
        server.start();
    }
}
