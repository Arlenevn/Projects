package org.example;

import org.example.World.Obstacle;
import org.example.World.World;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class ServerCommands {


    /**
     * handles the client commands
     * @param response - What is to be printed out
     * @param connectionThread - Used to close the tread
     */
    public static void Commands(String response, Thread connectionThread){
        World world = new World();
        // Check if the command is "dump".
        if (Objects.equals(response.toLowerCase(), "dump")){
            // Get the list of obstacles.
            List<Obstacle> obs = new World().getList();
            // Get the list of robots.
            ArrayList<Robot> robotList = new World().getRobotList();
            // Print the list of obstacles.
            System.out.println("List of obstacles in the world: ");
            for(Obstacle i : obs){
                System.out.println("* Obstacle at :"+i.getX()+","+i.getY());
            }
            // Print the list of robots.
            System.out.println("Robots in the world: ");
            for (Robot i : robotList) {
                List<Integer> a = i.getPosition();
                System.out.println(i.getName() + " is in the world at position " + a.get(0)+", "+a.get(1));
            }
        }
        else if (Objects.equals(response.toLowerCase(), "robot")){
                // Print the information for each robot.
                for (Robot entry : world.getRobotList()){
                    String name = entry.getName();
                    System.out.println("* Name: "+ name);
                    List<Integer> pos = entry.getPosition();
                    System.out.println("* Position :"+pos);
                    String status = entry.getStatus();
                    System.out.println("* Status: "+status);
                    int ammo = entry.getAmmo();
                    System.out.println("* Ammo count: "+ammo);
                    int shields = entry.getShieldValue();
                    System.out.println("* Shield count: "+shields+"\n");
                }


        }
        else if (Objects.equals(response.toLowerCase(), "quit")){

            // Interrupt the connection thread
            connectionThread.interrupt();
            // Interrupt all the running ClientHandler threads
            for (Thread thread : Thread.getAllStackTraces().keySet()) {
                if (thread instanceof Server.ClientHandler) {
                    thread.interrupt();
                }
            }
            System.out.println("Closing servers...");
            System.exit(0);
        }
        else{
            // The command is invalid.
            System.out.println("Invalid command");
        }
    }
    /**
     * Prints the information for all the robots in the world.
     *
     * @param world The world that contains the robots.
     */
    public static void Robots(World world) {
        for (Robot robot :  world.getRobotList())  {
            String response = "\n" + "     position: " + robot.getPosition() + "\n" +
                    "     direction: " + robot.getDirection() + "\n" +
                    "     shield: " + robot.getShieldValue() + "\n" +
                    "     shots: " + robot.getAmmo() + "\n" +
                    "     status: " + robot.getStatus() + "\n";
            System.out.println(response);
        }
    }
}
