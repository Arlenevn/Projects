package org.example;

import java.util.List;
import java.util.Objects;

import org.example.World.World;


public class fireCommand {

    /**
     * Executes the fire command for the given robot and world.
     *
     * @param robot The robot performing the fire command.
     * @param world The world in which the robot is located.
     * @return A string indicating the result of the fire command.
     */
    public static String fire(Robot robot, World world) {
        robot.setAmmo(false);
        String dir = robot.getDirection();
        String hit = checkHit(dir, world, robot);
        if (!Objects.equals(hit, "")){
            hit = hit + " was hit. Nice XD";
            return hit;
        }else{
            return "You missed :(";
        }
    }
    /**
     * Checks if the robot's fire command hits any enemy robot in the specified direction.
     *
     * @param dir   The direction in which the robot is firing.
     * @param world The world in which the robot is located.
     * @param robot The robot performing the fire command.
     * @return The name of the enemy robot that was hit, or an empty string if no robot was hit.
     */
    public static String checkHit(String dir, World world, Robot robot) {
        boolean hit = false;
        List<Integer> position = robot.getPosition();
        String name = "";
        for (Robot entry : world.getRobotList()) {
            List<Integer> enemyPos = entry.getPosition();
            switch (dir) {
                case "North":
                    if ((position.get(0) >= enemyPos.get(0)) && (position.get(0) <= enemyPos.get(0) + 4)) {
                        if ((enemyPos.get(1) <= 200) && (enemyPos.get(1) > position.get(1))) {
                            hit = true;
                            name = entry.getName();
                            entry.setShieldValue(false);
                            if(entry.getShieldValue()==0){
                                entry.setStatus("Dead");
                                entry.updatePosition(1000,1000);
                            }
                            return name;
                        }
                    }
                case "East" :
                    if ((position.get(1) >= enemyPos.get(1)) && (position.get(1) <= enemyPos.get(1) + 4)) {
                        if ((enemyPos.get(0) <= 200) && (enemyPos.get(0) > position.get(0))) {
                            hit = true;
                            name = entry.getName();
                            entry.setShieldValue(false);
                            if(entry.getShieldValue()==0){
                                entry.setStatus("Dead");
                                entry.updatePosition(1000,1000);
                            }
                            return name;
                        }
                    }
                case "South" :
                    if ((position.get(0) >= enemyPos.get(0)) && (position.get(0) <= enemyPos.get(0) + 4)) {
                        if ((enemyPos.get(1) + 4 >= -200) && (enemyPos.get(1) < position.get(1))) {
                            hit = true;
                            name = entry.getName();
                            entry.setShieldValue(false);
                            if(entry.getShieldValue()==0){
                                entry.setStatus("Dead");
                                entry.updatePosition(1000,1000);
                            }
                            return name;
                        }
                    }
                case "West" :
                    if ((position.get(1) >= enemyPos.get(1)) && (position.get(1) <= enemyPos.get(1) + 4)) {
                        if ((enemyPos.get(0) + 4 >= -200) && (enemyPos.get(0) < position.get(0))) {
                            hit = true;
                            name = entry.getName();
                            entry.setShieldValue(false);
                            if(entry.getShieldValue()==0){
                                entry.setStatus("Dead");
                                entry.updatePosition(1000,1000);
                            }
                            return name;
                        }
                    }
            }
        }
        return name;
    }
}
