
package org.example;

import java.io.IOException;


/**
 This class represents a state command.
 It extends the Server class and provides a method to get the state of the server.
 */

public class StateCommand extends Server{

    public StateCommand(int port) throws IOException {
        super(port);
    }

    public static String state() {
        return "{ name:Hal, Direction: north}";

    }

}
