package org.example;

import com.google.gson.Gson;
import java.io.File;
import java.io.Reader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Robot keeps track of everything related to the Robots
// Position, name, direction, shield, state, ammo, robot type
public class Robot {
    private String status;
    private final String name;
    private List<Integer> position = new ArrayList<>();
    private static String direction;
    private int ammo;
    private int shieldValue; //Shield should be an int not a boolean
    private Map<String,String> state = new HashMap<String, String>();

    private String robotType;
    public int maxShieldValue = 10;// default shield value
    public int maxAmmo = 17;// default ammo value
    public int visibility;


    //Constructor for the default robot type
    public Robot(String name, List<Integer> position) {
        this.name = name;
        this.status = "Ready"; // default state
        this.ammo = maxAmmo;
        this.shieldValue = maxShieldValue;
        this.robotType = "Default";
        this.direction = "North";
        this.position = position;
    }


    // Getter and setter for name
    public String getName() {
        return name;
    }

    // Getter and setter for direction
    public  String getDirection() {
        return direction;
    }

    public void updateDirection(String newDirection) {
        direction = newDirection;
    }

    // Getter and setter for shield
    public boolean setShieldValue(boolean recharging) {
        if (recharging) {
            this.shieldValue = this.maxShieldValue;
        } else {
            this.shieldValue--;
        }
        return this.shieldValue >= 0;
    }
    public int getShieldValue() {
        return shieldValue;
    }

    // return boolean and receive boolean = boolean recharging
    // if recharging == true, set shield to max value this.maxShieldValue = maxshield
    // else -1 from shieldValue
    // return shield >=0 (if true reload successful or hit taken and still alive or if false robot is dead)

    public void setMaxShieldValue(int newMaxShieldValue) {
        maxShieldValue = newMaxShieldValue;
    }

    public int getMaxShieldValue() {
        return maxShieldValue;
    }

    public void setStatus(String newStatus) {
        status = newStatus;
    }

    public String getStatus() {
        return status;
    }

    // Getter and setter for ammo
    public int getAmmo() {
        return ammo;
    }

    public boolean setAmmo(boolean reloading) {
        if (reloading) {
            this.ammo = maxAmmo;
        } else {
            this.ammo--;
        }
        return this.ammo >= 0;
    }

    public void setMaxAmmo(int newMaxAmmo) {
        maxAmmo = newMaxAmmo;
    }

    public int getMaxAmmo() {
        return maxAmmo;
    }

    public void setRobotType(String robotType) {
        this.robotType = robotType;
    }

    // Getter and setter for robotType
    public String getRobotType() {
        return robotType;
    }

    public void setVisibility(int newVisibility) {
        visibility = newVisibility;
    }

    public int getVisibility() {
        return this.visibility;
    }

    //    A method (getter/setter) to get the position and change position.
    //    getPosition and updatePosition

    public List<Integer> getPosition() {
        return this.position;
    }

    public void updatePosition(int x, int y) {
        this.position.clear();
        this.position.add(x);
        this.position.add(y);
    }

    //This method takes in the file name, the key to change, and the new value as parameters.
    // It then reads the contents of the JSON file, converts it to a Map object, and iterates through the map to find the key to change.
    // It then uses a switch case to change the value based on the key.
    public void configRobots(String robotType) throws Exception {
        // Create a new Gson instance
        Gson gson = new Gson();
        // Read the contents of the file into a string
        File file = new File("./configs/robot_config.json");
        Reader reader = Files.newBufferedReader(file.toPath());
        Map<String, Map<String, Object>> map = gson.fromJson(reader, Map.class);


        // Iterate through the map to get the values and keys of the JSON file
        //String here is the name of this Robot type
        //Map here is a Map of the data belonging to Robot Type that deviates from default.
        for (Map.Entry<String, Map<String, Object>> entry: map.entrySet()) {

            //String = "Scout" for example
            String key = entry.getKey();

            Map<String, Object> value = entry.getValue();

            //We use the setters declared here in Robot.java to replace the values.
            //e.g. setRobotType(entry.getValue) for "Scout".
            //This is where the Switch Case statement below comes in.
            //Since the values that deviate from the default aren't the same for every
            //robot type, we need to change which setters we call based on the type that
            //it is

            double maxShieldValue;
            double maxAmmo;
            double configVisibilty;

            switch (robotType) {
                case "Scout" :
                    value = (Map<String, Object>) value.get("Scout");
                    setRobotType("Scout");
                    maxShieldValue = (double) value.get("maxShieldValue");
                    maxAmmo = (double) value.get("maxAmmo");
                    configVisibilty = (double) value.get("visibility");
                    setMaxShieldValue((int) maxShieldValue);
                    setMaxAmmo((int) maxAmmo);
                    setVisibility((int) configVisibilty);
                    break;
                case "Sniper" :
                    value = (Map<String, Object>) value.get("Sniper");
                    setRobotType("Sniper");
                    System.out.println(value);
                    maxShieldValue = (double) value.get("maxShieldValue");
                    maxAmmo = (double) value.get("maxAmmo");
                    configVisibilty = (double) value.get("visibility");
                    setMaxShieldValue((int) maxShieldValue);
                    setMaxAmmo((int) maxAmmo);
                    setVisibility((int) configVisibilty);
                    break;
                case "Tank" :
                    value = (Map<String, Object>) value.get("Tank");
                    setRobotType("Tank");
                    maxShieldValue = (double) value.get("maxShieldValue");
                    maxAmmo = (double) value.get("maxAmmo");
                    setMaxShieldValue((int) maxShieldValue);
                    setMaxAmmo((int) maxAmmo);
                    break;
                case "Infiltrator" :
                    value = (Map<String, Object>) value.get("Infiltrator");
                    setRobotType("Infiltrator");
                    maxShieldValue = (double) value.get("maxShieldValue");
                    maxAmmo = (double) value.get("maxAmmo");
                    setMaxShieldValue((int)maxShieldValue);
                    setMaxAmmo((int) maxAmmo);
                    break;
                case "Engineer" :
                    value = (Map<String, Object>) value.get("Engineer");
                    maxShieldValue = (double) value.get("maxShieldValue");
                    maxAmmo = (double) value.get("maxAmmo");
                    setRobotType("Engineer");
                    setMaxShieldValue((int)maxShieldValue);
                    setMaxAmmo((int) maxAmmo);
                    break;
            }
        }
    }
}



