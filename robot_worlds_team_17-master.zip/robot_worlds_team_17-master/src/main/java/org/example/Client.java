package org.example;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.EOFException;

import com.google.gson.*;
import com.diogonunes.jcolor.*;

import static com.diogonunes.jcolor.Ansi.colorize;


public class Client {

    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    static Attribute outputColour = Attribute.BRIGHT_WHITE_TEXT();


    public Client(String host, int port) throws IOException {
        socket = new Socket(host, port);
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        inputStream = new ObjectInputStream(socket.getInputStream());
    }


    public void sendMessage(String message, String name, String type, Attribute colour) throws IOException {
        try{
        Gson gson = new Gson();
        type = type.toLowerCase();
        type = type.substring(0, 1).toUpperCase() + type.substring(1);
        String jsonString = gson.toJson(getJsonObject(name, message, type));
        outputStream.writeObject(jsonString);
        outputStream.flush();

        String response = null;
        try {
            response = (String) inputStream.readObject();

            JsonElement jsonElement = JsonParser.parseString(response);
            JsonObject message1 = jsonElement.getAsJsonObject();

            // get the values
            String command = message1.get("print").getAsString();
            //forgive me for the following switch case, it's easier than modifying the source of the response :pray:
            Attribute outColour;
            switch (command) {
                case "You can't go outside the zone...":
                case "Command not recognized, please check input and try again.":
                case "An obstacle blocks the way...":
                case "Oi, there's a robot in your way!":
                case "Please enter a valid step count for command.":
                    outColour = Attribute.BRIGHT_RED_TEXT();
                    break;
                default:
                    outColour = Attribute.BRIGHT_BLUE_TEXT();
                    break;
            }
            System.out.println(colorize("Server: " + command, outColour ));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }}catch (EOFException e){
            System.out.println("Lost connection to server :(");
            System.exit(0);
        }

    }

    private static Object getJsonObject(String robot, String command, String type) {

        String[] arguments = {type};

        // create an object to hold the JSON fields
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("robot", robot);
        jsonObject.addProperty("command", command);
        JsonArray argumentsArray = new JsonArray();
        for (String arg : arguments) {
            argumentsArray.add(arg);
        }
        jsonObject.add("arguments", argumentsArray);

        return jsonObject;
    }

    public void close() throws IOException {
        inputStream.close();
        outputStream.close();
        socket.close();
    }

    public static void main(String[] args) throws IOException {
        //Connects the client to server, by connecting to server port.
        Client client = null;
        Scanner scanner = new Scanner(System.in);
        String type = null;
        String termColour = "Unset";
        List<String> validTypes = new ArrayList<>();
        validTypes.add("sniper");
        validTypes.add("scout");
        validTypes.add("tank");
        validTypes.add("infiltrator");
        validTypes.add("engineer");

        while (true) {
            try {
                while (termColour.equals("Unset")) {
                    System.out.println("Would like like a coloured interface?");
                    System.out.println("    * White");
                    System.out.println("    * Pink");
                    System.out.println("    * Yellow");
                    System.out.println("    * Green");
                    termColour = scanner.nextLine().toLowerCase();

                    //set Output colour, used on most system outs
                    switch (termColour)  {
                        case "white":
                            break;
                        case "pink":
                            outputColour = Attribute.BRIGHT_MAGENTA_TEXT();
                            break;
                        case "yellow":
                            outputColour = Attribute.BRIGHT_YELLOW_TEXT();
                            break;
                        case "green":
                            outputColour = Attribute.BRIGHT_GREEN_TEXT();
                            break;
                    }
                }
                System.out.println(colorize("Enter an IP you would like to connect to: ", outputColour));
                String serverHost = scanner.nextLine(); // Replace with the IP address or domain name of the server
                int serverPort = 5000; // Replace with the port number used by the server

                client = new Client(serverHost, serverPort);
                break;
            } catch (UnknownHostException | ConnectException e) {
                System.out.println(colorize("Could not connect to host", Attribute.BRIGHT_RED_TEXT()));
            }
        }



        System.out.println(colorize("Name your robot: ", outputColour));
        String name = scanner.nextLine();
        while (true) {
            System.out.println(colorize("Enter the type of robot:", outputColour));
            list_robot_types();
            type = scanner.nextLine();

            if (validTypes.contains(type.toLowerCase())) {
                break;
            } else {
                System.out.println(colorize("invalid robot types", Attribute.BRIGHT_RED_TEXT()));
            }
        }
        System.out.println(colorize("You are not yet launched into the world.", Attribute.BRIGHT_RED_TEXT()));
        while (true) {
            //Asking for a Robot command.
            //Sends through sendMessage method and waits for a response.
            System.out.print(colorize("Enter a command: ", outputColour));
            String message = scanner.nextLine();
            if (message.equals("quit")) {
                client.sendMessage(message, name, type, outputColour);
                break;
            } else if (message.equals("help")) {
                help_command();
            } else if (message.equals("list robots")) {
                System.out.println("Here is the list of our robots:");
                list_robot_types();
            } else {
                client.sendMessage(message, name, type, outputColour);
            }


        }

        client.close();
    }

    public static void help_command() {
        //Setting the colour to blue on each of these individually
        //I would much rather do a multi-line string, but it's not supported in JDK11, so i'll have to settle for this monstrosity
        //-Jaden, the person who would rather not do this, sorry.
        System.out.println("I can understand these commands:");
        System.out.println("Quit - disconnects all robots and ends the world");
        System.out.println("Look - The robot can look around for the maximum distance specified by the world. Use the command look to look around in all four directions");
        System.out.println("State - Ask the world for the state of the robot");
        System.out.println("Forward - The robot can move forward in the direction it is facing with the command forward <steps>");
        System.out.println("Back - The robot can move backward in the direction opposite to what it is facing using  the command forward <steps>");
        System.out.println("Left - Instruct the robot to turn left");
        System.out.println("Right - Instruct the robot to turn right");
        System.out.println("Fire - A robot can be instructed to fire the gun");
        System.out.println("Repair - Robots can be instructed to rest in order to repair their shields to its configured maximum strength");
        System.out.println("Reload - Robots can be instructed to reload the gun using the command reload");
        System.out.println("Orientation - Can be used to find out which direction the robot is facing reported as North, South, East, West");
    }

    public static void list_robot_types() {
        System.out.println("Scout: Default robot with average stats");
        System.out.println("Sniper: Small mag, lower shield");
        System.out.println("Tank: high shield value, slow movement, regular mag");
        System.out.println("Infiltrator: Lower armour but higher visibility");
        System.out.println("Engineer: An extra robot cause why not");
    }
}