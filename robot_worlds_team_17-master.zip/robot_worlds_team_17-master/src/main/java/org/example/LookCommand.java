package org.example;
import org.example.World.Obstacle;
import org.example.World.World;

import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LookCommand {



    public static String Look(Robot robot, World world) throws IOException {
        // Get the list of obstacles in the world.
        List<Obstacle> obs = world.getList();
        // Get the list of obstacles in the world.
        Gson gson = new Gson(); //Gson googles package that interacts with Json.
        int count = 0;

        String robotDirection = robot.getDirection();
        List<Integer> pos = robot.getPosition();
        // Create a map to store the configuration values.
        Map<String, Integer> config = new HashMap<>();

        String response = "Obstacles visible:\n";

        File file = new File("./configs/config.json");
        Reader reader = Files.newBufferedReader(file.toPath());
        Map<?, ?> temp = gson.fromJson(reader, Map.class);
        for (Map.Entry<?, ?> entry : temp.entrySet()) {
            //Iterating through the map.
            double value = (double) entry.getValue();
            //1 to 1 transferring each entry into config map with data types.
            config.put((String) entry.getKey(), (int) value);
        }
        // Get the visibility of the robot.
        Integer visability = config.get("Visibility");

        switch (robotDirection) {
            case "North":
                for (Obstacle i : obs) {
                    if (i.getY() > pos.get(1) && i.getY() < pos.get(1) + visability) {
                        response = response + "Obstacle at " + i + "\n";
                        count += 1;
                    }
                }
                if (count == 0) {
                    response = "There are no visible obstacles\n";
                }
                    for (Robot entry : world.getRobotList()) {
                        System.out.println("here");
                        List<Integer> enemyPos = entry.getPosition();
                        if (pos.get(1) < enemyPos.get(1) && enemyPos.get(1) < pos.get(1)+ visability) {
                            response = response + "Robot at " + enemyPos + "\n";

                    }
                }
                break;
            case "East":
                for (Obstacle i : obs) {
                    if (i.getX() > pos.get(0) && i.getX() < pos.get(0) + visability) {
                        response = response + "Obstacle at " + i + "\n";
                        count += 1;
                    }
                }
                if (count == 0) {
                    response = "There are no visible obstacles\n";
                }
                for (Robot entry : world.getRobotList()) {
                    List<Integer> enemyPos = entry.getPosition();
                    if (pos.get(0) < enemyPos.get(0) && enemyPos.get(0) < pos.get(0)+ visability) {
                        response = response + "Robot at " + enemyPos + "\n";

                    }
                }
                break;
            case "South":
                for (Obstacle i : obs) {
                    if (i.getY() < pos.get(1) && i.getY() < pos.get(1) - visability) {
                        response = response + "Obstacle at " + i + "\n";
                        count += 1;
                    }
                }
                if (count == 0) {
                    response = "There are no visible obstacles\n";
                }
                for (Robot entry : world.getRobotList()) {
                    List<Integer> enemyPos = entry.getPosition();
                    if (pos.get(1) > enemyPos.get(1) && enemyPos.get(1) > pos.get(1)+ visability) {
                        response = response + "Robot at " + enemyPos + "\n";

                    }
                }
                break;
            case "West":
                for (Obstacle i : obs) {
                    if (i.getX() < pos.get(0) && i.getX() < pos.get(0) - visability) {
                        response = response + "Obstacle at " + i + "\n";
                        count += 1;
                    }
                }
                if (count == 0) {
                    response = "There are no visible obstacles\n";
                }
                for (Robot entry : world.getRobotList()) {
                    List<Integer> enemyPos = entry.getPosition();
                    if (pos.get(0) > enemyPos.get(0) && enemyPos.get(0) > pos.get(0)+ visability) {
                        response = response + "Robot at " + enemyPos + "\n";

                    }
                }
                break;
        }


        return response;
    }
}

