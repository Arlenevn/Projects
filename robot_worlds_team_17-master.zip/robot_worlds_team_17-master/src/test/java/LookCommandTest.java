import org.example.LookCommand;
import org.example.Robot;
import org.example.World.Obstacle;
import org.example.World.World;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LookCommandTest {
    @Test
    public void testLook_NoObstaclesOrRobotsVisible() throws IOException {
        List<Integer> position = new ArrayList<>();
        position.add(10);
        position.add(20);
        Robot robot = new Robot("Gary", position); // Creates a test robot object
        World world = new World(); // Creates a test world object

        String expectedResponse = "There are no visible obstacles\n";
        String actualResponse = LookCommand.Look(robot, world);

        Assertions.assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void testLook_ObstaclesVisible() throws IOException {
        // Creates a test robot object and set its position and direction
        List<Integer> position = new ArrayList<>();
        position.add(0);
        position.add(0);
        Robot robot = new Robot("Gary", position);

        // Create a test world object and add obstacles
        World world = new World();
        world.getList().add(new Obstacle(0, 1)); // Add obstacle at (0, 1)
        world.getList().add(new Obstacle(0, 2)); // Add obstacle at (0, 2)

        String expectedResponse = "Obstacles visible:\n";
        expectedResponse += "Obstacle at [0,1]\n";
        expectedResponse += "Obstacle at [0,2]\n";
        String actualResponse = LookCommand.Look(robot, world);

        Assertions.assertEquals(expectedResponse, actualResponse);
    }
}
