import org.example.World.Obstacle;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ObstacleTest {

    @Test
    public void testGetX() {
        Obstacle obstacle = new Obstacle(3, 4);
        int x = obstacle.getX();
        Assertions.assertEquals(3, x);
    }

    @Test
    public void testGetY() {
        Obstacle obstacle = new Obstacle(3, 4);
        int y = obstacle.getY();
        Assertions.assertEquals(4, y);
    }

    @Test
    public void testToString() {
        Obstacle obstacle = new Obstacle(3, 4);
        String expected = "[3,4]";
        String result = obstacle.toString();
        Assertions.assertEquals(expected, result);
    }
}
