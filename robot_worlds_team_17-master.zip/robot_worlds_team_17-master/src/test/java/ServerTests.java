import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.example.Server;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ServerTest {

    @Test
    void testGetJsonObject() throws IOException {
        // Prepare test data
        String printOut = "Test Print";
        String notPrint = "Test State";

        // Create an instance of the Server class
        Server server = new Server(5000);

        // Call the method under test
        Object result = server.getJsonObject(printOut, notPrint);

        // Perform assertions
        JsonObject jsonObject = (JsonObject) result;
        assertEquals(printOut, jsonObject.get("print").getAsString());
        assertEquals(notPrint, jsonObject.get("State").getAsString());

        JsonArray argumentsArray = jsonObject.get("arguments").getAsJsonArray();
        assertEquals(0, argumentsArray.size());
    }
}
