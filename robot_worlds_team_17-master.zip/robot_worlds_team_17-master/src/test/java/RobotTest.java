import org.example.Robot;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class RobotTest {
    private Robot robot;

    @Before
    public void setup() {
        List<Integer> position = new ArrayList<>();
        position.add(0);
        position.add(0);
        robot = new Robot("TestRobot", position);
    }

    @Test
    public void testGetName() {
        Assert.assertEquals("TestRobot", robot.getName());
    }

    @Test
    public void testGetDirection() {
        Assert.assertEquals("North", robot.getDirection());
    }

    @Test
    public void testUpdateDirection() {
        robot.updateDirection("South");
        Assert.assertEquals("South", robot.getDirection());
    }

    @Test
    public void testGetShieldValue() {
        Assert.assertEquals(10, robot.getShieldValue());
    }

    @Test
    public void testSetShieldValue() {
        boolean result = robot.setShieldValue(false);
        Assert.assertTrue(result);
        Assert.assertEquals(9, robot.getShieldValue());
    }

    @Test
    public void testGetAmmo() {
        Assert.assertEquals(17, robot.getAmmo());
    }

    @Test
    public void testSetAmmo() {
        boolean result = robot.setAmmo(false);
        Assert.assertTrue(result);
        Assert.assertEquals(16, robot.getAmmo());
    }

    @Test
    public void testGetRobotType() {
        Assert.assertEquals("Default", robot.getRobotType());
    }

    @Test
    public void testSetRobotType() {
        robot.setRobotType("Scout");
        Assert.assertEquals("Scout", robot.getRobotType());
    }

    @Test
    public void testGetPosition() {
        List<Integer> position = robot.getPosition();
        Assert.assertEquals(0, (int) position.get(0));
        Assert.assertEquals(0, (int) position.get(1));
    }

    @Test
    public void testUpdatePosition() {
        robot.updatePosition(1, 1);
        List<Integer> position = robot.getPosition();
        Assert.assertEquals(1, (int) position.get(0));
        Assert.assertEquals(1, (int) position.get(1));
    }

    @Test
    public void testConfigRobots() {
        try {
            robot.configRobots("Scout");
            Assert.assertEquals(10, robot.getMaxShieldValue());
            Assert.assertEquals(17, robot.getMaxAmmo());
            Assert.assertEquals(6, robot.getVisibility());
        } catch (Exception e) {
            Assert.fail("Exception thrown: " + e.getMessage());
        }
    }

    @Test
    public void testGetStatus() {
        Assert.assertEquals("Ready", robot.getStatus());
    }

    @Test
    public void testSetStatus() {
        robot.setStatus("Running");
        Assert.assertEquals("Running", robot.getStatus());
    }

    @Test
    public void testGetMaxShieldValue() {
        Assert.assertEquals(10, robot.getMaxShieldValue());
    }

    @Test
    public void testSetMaxShieldValue() {
        robot.setMaxShieldValue(15);
        Assert.assertEquals(15, robot.getMaxShieldValue());
    }

    @Test
    public void testGetMaxAmmo() {
        Assert.assertEquals(17, robot.getMaxAmmo());
    }

    @Test
    public void testSetMaxAmmo() {
        robot.setMaxAmmo(20);
        Assert.assertEquals(20, robot.getMaxAmmo());
    }

    @Test
    public void testGetVisibility() {
        Assert.assertEquals(0, robot.getVisibility());

    }
}