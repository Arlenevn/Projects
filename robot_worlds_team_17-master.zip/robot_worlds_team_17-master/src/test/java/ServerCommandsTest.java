import org.example.ServerCommands;
import org.example.World.World;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.util.List;
import java.util.ArrayList;
import static org.junit.Assert.*;

public class ServerCommandsTest {
    @Test
    public void testDump() throws IOException {
        // Given
        List<String> robotsConnected = new ArrayList<>();
        ServerSocket serverSocket = new ServerSocket();
        Thread connectionThread = new Thread();

        // When
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ServerCommands.Commands("dump", connectionThread);
        // Then
        assertEquals("List of obstacles in the world: \nRobots in the world: \n", outContent.toString());
    }

    @Test
    public void testInvalidCommand() throws IOException {
        // Given
        List<String> robotsConnected = new ArrayList<>();
        ServerSocket serverSocket = new ServerSocket();
        Thread connectionThread = new Thread();

        // When
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        ServerCommands.Commands("invalid", connectionThread);

        // Then
        assertEquals("Invalid command\n", outContent.toString());
    }
}
