import org.example.Client;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HelpCommandTest {
    @Test
    public void testHelpCommand() {
        // Redirect System.out to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the help_command() method
        Client.help_command();

        // Retrieve the printed output
        String output = outputStream.toString().trim();

        // Define the expected output
        String expectedOutput ="I can understand these commands:\n" +
                "Quit - disconnects all robots and ends the world\n" +
                "Look - The robot can look around for the maximum distance specified by the world. Use the command look to look around in all four directions\n" +
                "State - Ask the world for the state of the robot\n" +
                "Forward - The robot can move forward in the direction it is facing with the command forward <steps>\n" +
                "Back - The robot can move backward in the direction opposite to what it is facing using  the command forward <steps>\n" +
                "Left - Instruct the robot to turn left\n" +
                "Right - Instruct the robot to turn right\n" +
                "Fire - A robot can be instructed to fire the gun\n" +
                "Repair - Robots can be instructed to rest in order to repair their shields to its configured maximum strength\n" +
                "Reload - Robots can be instructed to reload the gun using the command reload\n" +
                "Orientation - Can be used to find out which direction the robot is facing reported as North, South, East, West";

        // Assert that the output matches the expected output
        assertEquals(expectedOutput, output);
    }

    @Test
    public void list_robot_types() {
        // Redirect System.out to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the help_command() method
        Client.list_robot_types();

        // Retrieve the printed output
        String output = outputStream.toString().trim();

        // Define the expected output
        String expectedOutput =
        "Scout: Default robot with average stats\n"+
        "Sniper: Small mag, lower shield\n"+
        "Tank: high shield value, slow movement, regular mag\n"+
        "Infiltrator: Lower armour but higher visibility\n"+
        "Engineer: An extra robot cause why not";

        // Assert that the output matches the expected output
        assertEquals(expectedOutput, output);
    }
}


