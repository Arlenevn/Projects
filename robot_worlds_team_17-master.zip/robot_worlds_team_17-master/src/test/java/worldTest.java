import org.example.Robot;
import org.example.World.Obstacle;
import org.example.World.World;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class worldTest {
    @Test
    public void testAddRobot() {

        World world = new World();
        List<Integer> position = new ArrayList<>();
        position.add(6);
        position.add(42);
        Assert.assertEquals(2, world.getRobotList().size());
        world.addRobot(new Robot("Yom", position));
        Assert.assertEquals(3, world.getRobotList().size());
    }

    @Test
    public void testGetConfigValue() {
        World world = new World();
        Assert.assertEquals(2, world.getConfigValue("ReloadSpeed"));
        Assert.assertEquals(5, world.getConfigValue("ShieldRepairTime"));
    }

    @Test
    public void testGenerateWorld() {
        World world = new World();
        World.generateWorld();
        Assert.assertTrue(world.getList().size() > 0);
    }

    @Test
    public void testObstacleCollision() {
        World world = new World();
        List<Integer> position = new ArrayList<>();
        position.add(1);
        position.add(1);
        Robot robot = new Robot("Yom", position);

        Assert.assertEquals("Success",world.checkCollision(robot, "East",  4, 1));

        World.generateWorld();
        Obstacle obstacle = world.getList().get(0);
        robot.updatePosition(obstacle.getX(), obstacle.getY() - 4);

        Assert.assertEquals("Obstacle", world.checkCollision(robot, "North", obstacle.getX(), obstacle.getY()));
    }

    @Test
    public void testEdgeCollision() {
        World world = new World();
        World.generateWorld();
        List<Integer> position = new ArrayList<>();
        position.add(-99);
        position.add(99);
        Robot robot = new Robot("Yom", position);

        Assert.assertEquals("Edge", world.checkCollision(robot, "North", -99, 101));
        Assert.assertEquals("Edge", world.checkCollision(robot, "West", -101, 99));
        robot.updatePosition(99, -99);
        Assert.assertEquals("Edge", world.checkCollision(robot, "East", 101, -99));
        Assert.assertEquals("Edge", world.checkCollision(robot, "South", 99, -101));
    }

    @Test
    public void testRobotCollision() {
        World world = new World();
        List<Integer> testPosition = new ArrayList<>();
        testPosition.add(0);
        testPosition.add(5);
        Robot robot = new Robot("Yom", testPosition);
        World.addRobot(robot);

        List<Integer> testPosition2 = new ArrayList<>();
        testPosition2.add(0);
        testPosition2.add(-5);
        World.addRobot(new Robot("Hal", testPosition2));
        Assert.assertEquals("Robot", world.checkRobotCollision(robot, "South", 0, -4));
    }

    @Test
    public void testHandleCommand() {
        World world = new World();
        List<Integer> testPosition = new ArrayList<>();
        testPosition.add(0);
        testPosition.add(5);
        Robot robot = new Robot("Yom", testPosition);

        world.handleCommand(robot, "forward 10");
        Integer position = robot.getPosition().get(1);
        Assert.assertEquals((Integer) 15, position);

        world.handleCommand(robot, "right");
        String direction = robot.getDirection();
        Assert.assertEquals("East", direction);

        world.handleCommand(robot, "left");
        direction = robot.getDirection();
        Assert.assertEquals("North", direction);
    }
}
