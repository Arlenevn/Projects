import static org.junit.Assert.assertEquals;

import org.example.Robot;
import org.example.World.World;
import org.example.fireCommand;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class FireTest {

    @Test
    public void testFire_TargetHit() {

        List<Integer> position = new ArrayList<>();
        position.add(0);
        position.add(0);

        Robot robot = new Robot("hal", position);
        World world = new World();

        String result = fireCommand.fire(robot, world);

        assertEquals("You missed :(", result);
        assertEquals(16, robot.getAmmo());
    }

    @Test
    public void testFire_MissedTarget() {
        List<Integer> position = new ArrayList<>();
        position.add(0);
        position.add(0);
        Robot robot = new Robot("hal",position);
        World world = new World();

        // Assuming the checkHit() method always returns false
        String result = fireCommand.fire(robot, world);

        assertEquals("You missed :(", result);
        assertEquals(16, robot.getAmmo());
    }
}
