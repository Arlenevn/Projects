package wethinkcode.places;


import com.google.common.annotations.VisibleForTesting;
import com.google.common.reflect.TypeToken;
import io.javalin.Javalin;
import picocli.CommandLine;
import wethinkcode.places.db.memory.PlacesDb;
import wethinkcode.places.model.Places;
import wethinkcode.places.model.Town;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.List;


/**
 * I provide a Place-names Service for places in South Africa.
 * <p>
 * I read place-name data from a CSV file that I read and
 * parse into the objects (domain model) that I use,
 * discarding unwanted data in the file (things like mountain/river names). With my "database"
 * built, I then serve-up place-name data as JSON to clients.
 * <p>
 * Clients can request:
 * <ul>
 * <li>a list of available Provinces
 * <li>a list of all Towns/PlaceNameService in a given Province
 * <li>a list of all neighbourhoods in a given Town
 * </ul>
 * I understand the following command-line arguments:
 * <dl>
 * <dt>-c | --config &lt;configfile&gt;
 * <dd>a file pathname referring to an (existing!) configuration file in standard Java
 *      properties-file format
 * <dt>-d | --datadir &lt;datadirectory&gt;
 * <dd>the name of a directory where CSV datafiles may be found. This option <em>overrides</em>
 *      and data-directory setting in a configuration file.
 * <dt>-p | --places &lt;csvdatafile&gt;
 * <dd>a file pathname referring to a CSV file of place-name data. This option
 *      <em>overrides</em> any value in a configuration file and will bypass any
 *      data-directory set via command-line or configuration.
 */
@CommandLine.Command(
        name = "PlaceNameService",
        description = "Provide a command for places",
        mixinStandardHelpOptions = true // Add standard help options (--help, --version)

)
public class PlaceNameService implements Runnable {

    public static final int DEFAULT_SERVICE_PORT = 7000;

    // Configuration keys
    public static final String CFG_CONFIG_FILE = "config.file";
    public static final String CFG_DATA_DIR = "data.dir";
    public static final String CFG_DATA_FILE = "data.file";
    public static final String CFG_SERVICE_PORT = "server.port";

    private static File file = new File("/home/wtc/student_work/submission-loadshedding-1/places/resources/PlaceNamesZA2008.csv");

    @CommandLine.Option(names = {"-c", "--config"}, description = "Configuration file")
    private String configFile;

    @CommandLine.Option(names = {"-d", "--datadir"}, description = "Data directory")
    private String dataDir;

    @CommandLine.Option(names = {"-p", "--places"}, description = "CSV data file")
    private String csvDataFile;

    @CommandLine.Option(names = {"-h", "--help"}, usageHelp = true, description = "Display help message")
    private boolean helpRequested;

    @CommandLine.Option(names = {"-V", "--version"}, versionHelp = true, description = "Display version info")
    private boolean versionRequested;
    private static Javalin server;
    private Places places;

    public static void main( String[] args ){ // check if arg exists then set next arg as the csv file path run this in a for loop (for to run through args, if to check args

        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-c") || args[i].equals("--config")) {
                if (i + 1 > args.length) {
                    file = new File(args[i + 1]);
                    i++;
                } else {
                    System.err.println("Missing argument for --config");
                    System.exit(1);
                }
            } else if (args[i].equals("-p") ||args[i].equals("--places")) {
                if (i +1 < args.length) {
                    file = new File(args[i + 1]);
                    i++;
                } else {
                    System.err.println("Missing argument for --places");
                    System.exit(1);
                }


            }
        }
        PlaceNameService service = new PlaceNameService().initialise();
        new CommandLine(service).execute();

    }

    public PlaceNameService(){
    }



    public static void stop(){
        if (server != null) {
            server.stop();
        }
    }

    /**
     * Why not put all of this into the constructor? Well, this way makes
     * it easier (possible!) to test an instance of PlaceNameService without
     * starting up all the big machinery (i.e. without calling initialise()).
     */
    @VisibleForTesting
    PlaceNameService initialise(){
        places = initPlacesDb();
        server = initHttpServer();
        return this;
    }

//    public void start(){
//        PlacesCsvParser parser = new PlacesCsvParser();
//        if (csvDataFile != null) {
//            File csvFile = new File(csvDataFile);
//            parser.parseCsvSource(csvFile);
//        }
//        // intialise server before starting it
//        initialise();
//
//        server.start();
//    }

    @Override
    public void run(){
        PlacesCsvParser parser = new PlacesCsvParser();
        parser.parseCsvSource(file);
    }

    private Places initPlacesDb() {
        return new PlacesDb();
    }

    private Javalin initHttpServer(){
        Javalin app = Javalin.create().start(DEFAULT_SERVICE_PORT);
        run();
        // Define routes
        app.get("/provinces", context -> {
            Collection<String> provinces = places.provinces();
            if (provinces.isEmpty()) {
                context.status(404).json(new Error("No provinces found"));
            } else {
                context.json(provinces); // check if a valid province, if not it should not return
            }

        } );

        app.get("/towns/{province}", context -> {
            String province = context.pathParam("province");
            Collection<Town> towns = places.townsIn(province);
            if (towns.isEmpty()) {
                context.status(404).json(new Error("Province not found"));
            } else {
                context.json(towns);
            }
        });
//
//        app.post("/towns/{province}", context -> {
//            String province = context.pathParam("province");
//            List<Town> townsToAdd = context.bodyAsClass(new TypeToken<List<Town>>() {}.getType());
//
//            if (townsToAdd.isEmpty()) {
//                context.status(400).json(new Error("Towns list is empty"));
//            } else {
//                places.townsIn(province);
//                context.status(201); // created
//            }
//        } );
//
//        int port = Integer.parseInt(System.getProperty(CFG_SERVICE_PORT, String.valueOf(DEFAULT_SERVICE_PORT)));
//        app.port();

        return app;
    }
}