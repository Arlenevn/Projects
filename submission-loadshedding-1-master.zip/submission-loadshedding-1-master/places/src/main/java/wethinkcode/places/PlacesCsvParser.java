package wethinkcode.places;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.google.common.annotations.VisibleForTesting;
import com.google.gson.Gson;
import wethinkcode.places.db.memory.PlacesDb;
import wethinkcode.places.model.Town;
import wethinkcode.places.model.Places;



/**
 * PlacesCsvParser : I parse a CSV file with each line containing the fields (in order):
 * <code>Name, Feature_Description, pklid, Latitude, Longitude, Date, MapInfo, Province,
 * fklFeatureSubTypeID, Previous_Name, fklMagisterialDistrictID, ProvinceID, fklLanguageID,
 * fklDisteral, Local Municipality, Sound, District Municipality, fklLocalMunic, Comments, Meaning</code>.
 * <p>
 * For the PlaceNameService we're only really interested in the <code>Name</code>,
 * <code>Feature_Description</code> and <code>Province</code> fields.
 * <code>Feature_Description</code> allows us to distinguish towns and urban areas from
 * (e.g.) rivers, mountains, etc. since our PlaceNameService is only concerned with occupied places.
 */
public class PlacesCsvParser {

    // accept file, read file, update list from resources/PlaceNamesZA2008.csv
    // name, feature, province needs to be filtered out and create new JSON file with the values
    // use a data map, then check feature, if town or urban add to list, convert list to GSON
    // GSON then converts to JSON, JSON should be a string, then write to a new file
    // create a new places database and add the JSON string file which then gets added to provinces.
    public Places parseCsvSource(File csvFile) {
        List<Town> towns = new ArrayList<>();

        try (CSVReader csvReader = new CSVReaderBuilder(new FileReader(csvFile)).withSkipLines(1).build()) {
            String[] nextRecord;
            while ((nextRecord = csvReader.readNext()) != null) {
                Map<String, String> dataMap = new LinkedHashMap<>();

                dataMap.put("Name", nextRecord[0]);
                dataMap.put("Feature_Description", nextRecord[1]);
                dataMap.put("Province", nextRecord[7]);
                if (isTownOrUrbanArea(dataMap.get("Feature_Description"))) {
                    Town town = new Town(dataMap.get("Name"), dataMap.get("Province"));
                    towns.add(town);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create a Gson object for JSON serialization
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        // Convert the list of towns to JSON
        String jsonData = gson.toJson(towns);

        // Save the JSON data to a file (optional)
        try (FileWriter jsonFile = new FileWriter("csv.json")) {
            jsonFile.write(jsonData);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create a PlacesDb and add the JSON data to provinces
        Places provinces = new PlacesDb();
        provinces.provinces().add(jsonData);


        return provinces;
    }
    @VisibleForTesting
    Places parseDataLines( final LineNumberReader in ){
        Places db = new PlacesDb(); // Assuming PlacesDb implements the Places interface

        try {
            String line;
            while ((line = in.readLine()) != null) {
                String[] data = line.split(","); // Assuming CSV data is comma-separated
                if (data.length >= 5) { // Assuming you need at least 5 columns
                    String name = data[0];
                    String featureDescription = data[1];
                    String province = data[7];

                    if ((featureDescription.equals("Town") && !province.isEmpty())){
                        Town place = new Town(name, province);
                        db.add(String.valueOf(place));
                    }
                    if ((featureDescription.equals("Urban Area")) && !province.isEmpty()){
                        Town place = new Town(name, province);
                        db.add(String.valueOf(place));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return db;
    }

    int splitLineIntoValues(String line) {
        String[] values = line.split(",", -1);

        return values.length;
    }

    private boolean isTownOrUrbanArea(String featureDescription) {
        // Define keywords to identify towns and urban areas
        String[] townKeywords = { "Town", "Urban Area" };

        for (String keyword : townKeywords) {
            if (featureDescription.equals(keyword)) {
                return true;
            }
        }

        return false;
    }
}