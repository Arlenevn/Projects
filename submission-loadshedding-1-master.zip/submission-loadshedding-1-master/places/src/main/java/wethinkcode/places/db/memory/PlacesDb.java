package wethinkcode.places.db.memory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import wethinkcode.places.model.Places;
import wethinkcode.places.model.Town;

/**
 * TODO: javadoc PlacesDb
 */
public class PlacesDb implements Places {

    private Map<String, Collection<Town>> townMap = new HashMap<>();
    private static Collection<String> places = new ArrayList<>();

    // read the JSON string file gets read and returns a list of the provinces
    @Override
    public Collection<String> provinces() {
        Collection<String> provinces = new ArrayList<>();

        try {
            String jsonFilePath = "csv.json";
            List<Map<String, String>> data = readJsonFile(jsonFilePath);
            for (Map<String, String> record : data) {
                String province = record.get("province");
                if (!province.isEmpty() && !provinces.contains(province)) {
                    provinces.add(province);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return provinces;
    }

    public List<Map<String, String>> readJsonFile(String jsonFilePath) throws IOException {
        try (FileReader fileReader = new FileReader(jsonFilePath)) {
            Gson gson = new Gson();
            Type mapType = new TypeToken<List<Map<String, String>>>() {}.getType();
            return gson.fromJson(fileReader, mapType);
        }
    }

    // check given province and return towns in said province. Should also be a list.
    @Override
    public Collection<Town> townsIn(String aProvince) {
        Collection<Town> townsIn = new ArrayList<>();

        try {
            String jsonFilePath = "csv.json";
            List<Map<String, String>> data = readJsonFile(jsonFilePath);
            for (Map<String, String> record : data) {
                String town = record.get("name");
                String province = record.get("province");
                Town newTown = new Town(town, province);
                if (Objects.equals(province, aProvince)) {
                    townsIn.add(newTown);
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return townsIn;
    }

    @Override
    public int size() {

        return places.size();
    }

//    @Override
//    public void addTownsToProvince(String province, List<Town> towns) {
//        if (towns != null) {
//            townMap.computeIfAbsent(province, k -> new ArrayList<>()).addAll(towns);
//        }
//    }

    @Override
    public void add(String town) {
        places.add(town);
    }

    public void readCsvData() {
        if (townMap.isEmpty()) {
            try (BufferedReader reader = new BufferedReader(new FileReader("resources/PlaceNamesZA2008.csv"))) {
                String line;
                // skip header
                reader.readLine();

                while ((line = reader.readLine()) != null) {
                    String[] fields = line.split(",");

                    if (fields.length >= 8) {
                        String name = fields[0].trim();
                        String description = fields[1].trim();
                        String provinces = fields[7].trim();

                        // create a new town object
                        Town town = new Town(name, description);

                        // add the town to the province in the map
                        townMap.computeIfAbsent(provinces, k -> new ArrayList<>()).add(town);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
