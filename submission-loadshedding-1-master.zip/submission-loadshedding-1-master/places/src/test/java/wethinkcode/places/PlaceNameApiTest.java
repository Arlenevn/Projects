package wethinkcode.places;

import java.io.IOException;

import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import org.junit.jupiter.api.*;
import wethinkcode.places.db.memory.PlacesDb;
import wethinkcode.places.model.Places;

import static org.junit.jupiter.api.Assertions.*;

/**
 * *Functional* tests of the PlaceNameService.
 */
public class PlaceNameApiTest
{
    public static final int TEST_PORT = 7000;

    private static PlaceNameService server;
    private static Places placesDb;

    @BeforeAll
    public static void startServer() {
        server = new PlaceNameService();

        // Initilise DB
        placesDb = new PlacesDb();
        placesDb.readCsvData();
//        placesDb.initializeWithData(PlacesTestData.CSV_DATA);
//        //Start server
//        server = new PlaceNameService(TEST_PORT, placesDb);
//        server.start();
    }

    @AfterAll
    public static void stopServer(){
        server.stop();
    }

    @Test
    public void getProvincesJson(){
        HttpResponse<JsonNode> response = Unirest.get(serverUrl() + "/provinces").asJson();
        assertEquals(200, response.getStatus());
    }

    @Test
    public void getTownsInAProvince_provinceExistsInDb(){
        HttpResponse<JsonNode> response = Unirest.get( serverUrl() + "/towns/KwaZulu-Natal" ).asJson();
        assertEquals(200, response.getStatus());
    }

    @Test
    public void getTownsInAProvince_noSuchProvinceInDb(){
        HttpResponse<JsonNode> response = Unirest.get( serverUrl() + "/towns/Oregon" ).asJson();
        assertEquals(404, response.getStatus());
    }

    private String serverUrl(){
        return "http://localhost:" + TEST_PORT;
    }
}
