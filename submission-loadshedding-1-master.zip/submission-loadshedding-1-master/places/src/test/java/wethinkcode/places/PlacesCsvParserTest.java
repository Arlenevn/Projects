package wethinkcode.places;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.junit.jupiter.api.*;
import wethinkcode.places.model.Places;
import wethinkcode.places.model.Town;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

/**
 * Unit-test suite for the CSV parser.
 */
public class PlacesCsvParserTest
{
    private File inputFile;

    private LineNumberReader input;

    private PlacesCsvParser parser;

    private Places places;

    private String TEST_FILE_PATH = "testData.csv";

    public void createCSV(String testLine) {
        try {
            FileWriter writer = new FileWriter(TEST_FILE_PATH);
            writer.write(testLine);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void deleteCSV() {
        // Delete the CSV file when the test is complete
        Path path = Paths.get(TEST_FILE_PATH);
        try {
            java.nio.file.Files.deleteIfExists(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @BeforeEach
    public void setUp(){
        input = new LineNumberReader( new StringReader( PlacesTestData.CSV_DATA ));
        parser = new PlacesCsvParser();
    }

    @AfterEach
    public void tearDown(){
        places = null;
        parser = null;
//        input = null;
    }

    @Test
    public void firstLineGetsSkipped() {
       final String testLine = """
               Name,Feature_Description,pklid,Latitude,Longitude,Date,MapInfo,Province,fklFeatureSubTypeID,Previous_Name,fklMagisterialDistrictID,ProvinceID,fklLanguageID,fklDisteral,Local Municipality,Sound,District Municipality,fklLocalMunic,Comments,Meaning""";
           createCSV(testLine);
           File file = new File(TEST_FILE_PATH);
           Places towns = parser.parseCsvSource(file);
           assertEquals(0, towns.provinces().size()); // check that first line is skipped
    }

    @Test
    public void splitLineIntoValuesProducesCorrectNoOfValues(){
        final String testLine = "Brakpan,Non_Perennial,92797,-26.60444444,26.34,01-06-1992,,North West,66,,262,8,16,DC40,Matlosana,,,NW403,,";
        int test = parser.splitLineIntoValues(testLine);
        assertEquals(20, test);
    }

    @Test
    public void urbanPlacesAreWanted(){
        final String testLine = """
                    Name,Feature_Description,pklid,Latitude,Longitude,Date,MapInfo,Province,fklFeatureSubTypeID,Previous_Name,fklMagisterialDistrictID,ProvinceID,fklLanguageID,fklDisteral,Local Municipality,Sound,District Municipality,fklLocalMunic,Comments,Meaning
                    Brakpan,Urban Area,92799,-26.23527778,28.37,31-05-1995,,Gauteng,114,,280,3,16,EKU,Ekurhuleni Metro,,,EKU,,""";
        createCSV(testLine);
        File file = new File(TEST_FILE_PATH);
        Places towns = parser.parseCsvSource(file);
        assertEquals(1, towns.townsIn("Gauteng").size());
        deleteCSV();
    }

    @Test
    public void townsAreWanted(){
        final String testLine = """
                    Name,Feature_Description,pklid,Latitude,Longitude,Date,MapInfo,Province,fklFeatureSubTypeID,Previous_Name,fklMagisterialDistrictID,ProvinceID,fklLanguageID,fklDisteral,Local Municipality,Sound,District Municipality,fklLocalMunic,Comments,Meaning
                    Brakpan,Town,92802,-27.95111111,26.53333333,30-05-1975,,Free State,68,,155,2,16,DC18,Matjhabeng,,,FS184,,""";
        createCSV(testLine);
        File file = new File(TEST_FILE_PATH);
        Places towns = parser.parseCsvSource(file);

        assertEquals(1, towns.townsIn("Free State").size()); // Ensure the urban area is wanted
        deleteCSV();
    }

    @Test
    public void otherFeaturesAreNotWanted(){
        final String testLine = """
                    Name,Feature_Description,pklid,Latitude,Longitude,Date,MapInfo,Province,fklFeatureSubTypeID,Previous_Name,fklMagisterialDistrictID,ProvinceID,fklLanguageID,fklDisteral,Local Municipality,Sound,District Municipality,fklLocalMunic,Comments,Meaning
                    Amatikulu,Station,95756,-29.05111111,31.53138889,31-05-1989,,KwaZulu-Natal,79,,237,4,16,DC28,uMlalazi,,,KZ284,,""";
        createCSV(testLine);
        File file = new File(TEST_FILE_PATH);
        Places towns = parser.parseCsvSource(file);
        assertEquals(0, towns.size()); // Ensure other features are not wanted
        deleteCSV();
    }

    @Test
    public void parseBulkTestData() {
        final Places db = parser.parseDataLines( input );
        assertEquals( 5, db.size() );
    }
}