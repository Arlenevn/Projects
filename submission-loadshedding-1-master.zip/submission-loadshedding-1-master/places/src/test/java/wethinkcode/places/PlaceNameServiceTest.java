package wethinkcode.places;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import kong.unirest.JsonNode;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import static org.junit.jupiter.api.Assertions.*;

public class PlaceNameServiceTest {

    @Test
    public void getACsvFileIntoTheServer() {
        try {
            final File csvFile = createTestCsvFile();
            final String[] args = {"-p", csvFile.getPath()};
            PlaceNameService.main(args);
            // You should not call the main method here. The server should be running in the background.
            HttpResponse<JsonNode> response = Unirest.get("http://localhost:7000" + "/provinces").asJson();

            assertNotNull(response.getBody());
            assertEquals(5, response.getBody().getArray().length());

        } catch (IOException ex) {
            fail(ex);
        }
    }

    private File createTestCsvFile() throws IOException {
        final File f = File.createTempFile("places", "csv");
        f.deleteOnExit();

        try (FileWriter out = new FileWriter(f)) {
            out.write(PlacesTestData.CSV_DATA);
            return f;
        }
    }
}
