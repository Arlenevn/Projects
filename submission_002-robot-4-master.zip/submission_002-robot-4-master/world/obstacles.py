import random

obstacle_blocks = []
x_move = 0 
y_move = 0

def obstacle_reset():
    global obstacle_blocks
    obstacle_blocks = []

def is_position_blocked(x,y):
    
    blocked_position = False

    for position in obstacle_blocks:
        if x in range(position[0], position[0]+5) and y in range(position[1], position[1]+5):
            blocked_position = True
            return blocked_position
    return blocked_position


def is_path_blocked(x1,y1, x2, y2):
    
    blocked_path = False
    range_of_x = range(x1, x2)
    range_of_y = range(y1, y2)

    if x1 == x2:
        if y1 < y2:
            for area in range_of_y:
                if is_position_blocked(x1, area):
                    blocked_path = True
                    return blocked_path

        if y1 > y2:
            range_of_y = range(y1, y2 -1)
            for area in range_of_y:
                if is_position_blocked(x1, area):
                    blocked_path = True
                    return blocked_path

    if y1 == y2:
        if x1 < x2:
            for area in range_of_x:
                if is_position_blocked(area, y1):
                    blocked_path = True
                    return blocked_path

        if x1 > x2:
            range_of_x = (x1, x2, -1)
            for area in range_of_x:
                if is_position_blocked(area, y1):
                    blocked_path = True
                    return blocked_path
    
    return blocked_path


def get_obstacles():
    
    random_obstacles = random.randint(1, 11)

    for move in range(random_obstacles):
        x_move = random.randint (-100, 100)
        y_move = random.randint (-200, 200)
        obstacle_blocks.append((x_move, y_move))

    if random_obstacles != 0: 
        print(f"There are some obstacles:")
        for x_move, y_move in obstacle_blocks:
            print (f"- At position {x_move},{y_move} (to {x_move+4},{y_move+4})")


