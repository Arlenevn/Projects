from io import StringIO
import unittest
import robot
from test_base import captured_io
import sys

from world import obstacles
import world


class MyTestCase(unittest.TestCase):

    def test_text_world_exist(self):

        self.assertTrue('world' in sys.modules , "text_world module should be found")

