INSERT INTO books (title, genre_code)
VALUES ('Test Driven Development', 'PROG');

INSERT INTO books (title, genre_code)
VALUES ('Programming in Haskell', 'PROG');

INSERT INTO books (title, genre_code)
VALUES ('Scatterlings of Africa', 'BIO');
