INSERT INTO genres(code, description)
VALUES ('SCIFI', 'Science Fiction');

INSERT INTO genres(code, description)
VALUES ('BIO', 'Biography');

INSERT INTO genres(code, description)
VALUES ('PROG', 'Programming');