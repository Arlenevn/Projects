CREATE TABLE Genres (
    code TEXT PRIMARY KEY NOT NULL,
    description TEXT NOT NULL
);