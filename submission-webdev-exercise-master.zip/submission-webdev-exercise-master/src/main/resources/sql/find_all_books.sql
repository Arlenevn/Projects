SELECT books.title, genres.description
FROM books
JOIN genres ON books.genre_code = genres.code;