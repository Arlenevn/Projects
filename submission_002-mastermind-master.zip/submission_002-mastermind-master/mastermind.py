import random

def length_check(p_userinput):
    if len(p_userinput) == 4:
        return True
    return False

def range_check(p_userinput):
    if p_userinput.isdigit():
        for num in p_userinput:
            if int(num) < 1 or int(num) > 8:
                return False
        return True
    else: return False

#STEP 1 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def run_game():
    master_code = []
    master_code_string = []

    while len(master_code) <4:
        code_gen = random.randint(1,8) #creates a random number in this range
        if code_gen not in master_code:
            master_code.append(code_gen)
            master_code_string.append(str(code_gen))
    print ("4-digit Code has been set. Digits in range 1 to 8. You have 12 turns to break it.")

    #STEP 4 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    turns = 12
    is_winner = False #until proven otherwise (according to Teboho)
    while turns >0 and not is_winner :
    #STEP 2 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        while True:
            user_input = input("Input 4 digit code: ")
            user_code = []
            if length_check(user_input) == True and range_check(user_input) == True:
                for nums in user_input:
                    user_code.append(int(nums))
                break
            else: 
                print ("Please enter exactly 4 digits.")
                continue

    #STEP 3 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        place_count = 0
        digit_count = 0
        for position, value in enumerate(master_code):
            if user_code[position] == value:
                place_count+=1
            elif user_code[position] in master_code:
                digit_count+=1

        print (f"Number of correct digits in correct place:     {place_count}")
        print (f"Number of correct digits not in correct place: {digit_count}")
    
        if master_code == user_code: 
            is_winner = True
            print("Congratulations! You are a codebreaker!")
            print(f"The code was: {''.join(master_code_string)}")
        else:
            turns -= 1
            print(f"Turns left: {turns}")





if __name__ == "__main__":
    run_game()
