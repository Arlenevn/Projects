package za.co.wethinkcode.toyrobot;

public class Position {
    private final int x;
    private final int y;

    public Position(int x, int y) {
        /*
         * This constructor initializes a new Position object with the provided x and y coordinates.
         *
         * Args:
         *     x (int): the x-coordinate of the position
         *     y (int): the y-coordinate of the position
         */
        this.x = x;
        this.y = y;
    }


    public int getX() {
        return x;
    }
    /*
     * This method returns the x-coordinate of the position.
     *
     * Returns:
     *     int: the x-coordinate of the position
     */

    public int getY() {
        return y;
    }
    /*
     * This method returns the y-coordinate of the position.
     *
     * Returns:
     *     int: the y-coordinate of the position
     */

    @Override
    public boolean equals(Object o) {
        /*
         * This method compares the current Position object to another object to determine if they are equal.
         *
         * Args:
         *     o (Object): the object to compare to the current Position object
         *
         * Returns:
         *     boolean: true if the objects are equal, false otherwise
         */
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Position position = (Position) o;

        if (x != position.x) return false;
        return y == position.y;
    }

    public boolean isIn(Position topLeft, Position bottomRight) {
        /*
         * This method checks whether the current Position object is within the bounds defined by the top-left and
         * bottom-right positions.
         *
         * Args:
         *     topLeft (Position): the top-left position of the bounding box
         *     bottomRight (Position): the bottom-right position of the bounding box
         *
         * Returns:
         *     boolean: true if the current Position object is within the bounding box, false otherwise
         */
        boolean withinTop = this.y <= topLeft.getY();
        boolean withinBottom = this.y >= bottomRight.getY();
        boolean withinLeft = this.x >= topLeft.getX();
        boolean withinRight = this.x <= bottomRight.getX();
        return withinTop && withinBottom && withinLeft && withinRight;
    }
}
