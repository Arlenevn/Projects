package za.co.wethinkcode.toyrobot;

import za.co.wethinkcode.toyrobot.world.AbstractWorld;
import za.co.wethinkcode.toyrobot.world.IWorld;
import za.co.wethinkcode.toyrobot.world.TextWorld;

/**
 * The Robot class represents a toy robot that can be moved
and directed in a two-dimensional space.*/
public class Robot {
    private Position position;
    public AbstractWorld world;
    private String status;
    private final String name;
    public static final Position CENTRE = new Position(0,0);
    private static Direction currentDirection;
    /*
     * Constructor method for Robot class.
     *
     * @param name The name of the robot.
     */
    public Robot(String name) {
        this.name = name;
        this.status = "Ready";
        this.world = new TextWorld();
        this.position = CENTRE;
        currentDirection = Direction.UP;
    }

    public Robot(String name, AbstractWorld world) {
        this.name = name;
        this.status = "Ready";
        this.world = world;
    }

    /**
     * Returns the current status of the robot.
     *
     * @return The status of the robot as a String.
     */
    public String getStatus() {
        return this.status;
    }
    /**
     * Executes a command on the robot.
     *
     * @param command The command to execute as a Command object.
     * @return True if the command was executed successfully, false otherwise.
     */
    public boolean handleCommand(Command command) {
        return command.execute(this);
    }

    /**
     * Returns a string representation of the robot's current state.
     *
     * @return A string representing the robot's current state.
     */

    @Override
    public String toString() {
        return "[" + world.getPosition().getX() + "," + world.getPosition().getY() + "] "
                + this.name + "> " + this.status;
    }

    private Position position() {
        return this.position;
    }

    /**
     * Sets the current status of the robot.
     *
     * @param status The new status of the robot as a String.
     */

    public void setStatus(String status) {
        /*Sets the status of the Robot*/
        this.status = status;
    }

    /**
     * Returns the name of the robot.
     *
     * @return The name of the robot as a String.
     */
    public String getName() {
        /*Returns the name of the robot*/
        return this.name;
    }

    public IWorld.UpdateResponse updatePosition(int nrSteps) {
        return world.updatePosition(nrSteps);
//        return worldOutput == IWorld.UpdateResponse.SUCCESS;
    }
}