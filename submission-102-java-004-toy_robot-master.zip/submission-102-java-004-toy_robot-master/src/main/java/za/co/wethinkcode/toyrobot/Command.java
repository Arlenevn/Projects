package za.co.wethinkcode.toyrobot;

import java.util.ArrayList;
import java.util.List;

public abstract class Command {
    private final String name; // The name of the command
    private String argument; // The argument associated with the command

    private static boolean commandReplaying;
    private static List<String> commandHistory = new ArrayList<>();
    /*
     * Executes the command on the given Robot.
     *
     * @param target the Robot on which the command is to be executed
     * @return true if the command was executed successfully, false otherwise
     */

    public abstract boolean execute(Robot target);
    /*
     * Constructs a new Command object with the given name.
     *
     * @param name the name of the command
     */
    public Command(String name) {
        this.name = name.trim().toLowerCase();
        this.argument = "";
    }
    /*
     * Constructs a new Command object with the given name and argument.
     *
     * @param name the name of the command
     * @param argument the argument associated with the command
     */


    public Command(String name, String argument) {
        this(name);
        this.argument = argument.trim();
    }
    /*
     * Returns the name of the command.
     *
     * @return the name of the command
     */


    public String getName() {                                                                           //<2>
        return name;
    }

    /*
     * Returns the argument associated with the command.
     *
     * @return the argument associated with the command
     */
    public String getArgument() {
        return this.argument;
    }

    public List<String> getCommandHistory() {
        return commandHistory;
    }

    public static void setCommandHistory(List<String> newCommandHistory) {
        commandHistory = new ArrayList<>(newCommandHistory);
    }

    public void setCommandReplaying(boolean replaying) {
        commandReplaying = replaying;
    }

    public static Command create(String instruction) {
        String[] args = instruction.toLowerCase().trim().split(" ");
        if (!instruction.contains("replay") && !instruction.contains("help") && ! commandReplaying) {
            commandHistory.add(instruction.toLowerCase());
        }
//        System.out.println(commandHistory);
        switch (args[0]) {
            case "shutdown":
            case "off":
                setCommandHistory(new ArrayList<>());
                return new ShutdownCommand();
            case "help":
                return new HelpCommand();
            case "left":
                return new LeftCommand();
            case "right":
                return new RightCommand();
            case "replay":
                switch (args.length) {
                    case 1:
                        return new ReplayCommand();
                    case 2:
                        return new ReplayCommand(args[1]);
                    case 3:
                        return new ReplayCommand(args[1], args[2]);
                }
            case "sprint":
                return new SprintCommand(args[1]);
            case "back":
                return new BackCommand(args[1]);
            case "forward":
                return new ForwardCommand(args[1]);
            case "mazerun":
                return new MazeRunnerCommand(args[1]);
            default:
                throw new IllegalArgumentException("Unsupported command: " + instruction);
        }
    }

}
























































































































































































































































































