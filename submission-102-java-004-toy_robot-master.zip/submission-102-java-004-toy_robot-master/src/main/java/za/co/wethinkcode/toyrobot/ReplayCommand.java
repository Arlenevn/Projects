package za.co.wethinkcode.toyrobot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class ReplayCommand extends Command{
    private boolean isReversed = false;
    private int startRange = -1;
    private int endRange = -1;

    // Default constructor with no arguments
    public ReplayCommand() {
        super("replay");
    }
    // Constructor with 1 argument
    public ReplayCommand(String arg1) {
        super("replay", arg1);
        parseArg(arg1);
    }
    // Constructor with two arguments
    public ReplayCommand(String arg1, String arg2) {
        super("replay", arg1 + " " + arg2);

        parseArg(arg1);
        parseArg(arg2);
    }

    public void parseArg(String arg) {
        // Method to parse a single command line argument and assign variables
        if (arg.equals("reversed")) {
            isReversed = true;
        } else if (arg.matches("\\d+")) {
            if (startRange == -1) {
                startRange = Integer.parseInt(arg);
            }
        } else if (arg.matches("\\d+-\\d+")) {
            String[] rangeArgs = arg.split("-");
            startRange = Integer.parseInt(rangeArgs[0]);
            endRange = Integer.parseInt(rangeArgs[1]);
        }
    }

    @Override
    public boolean execute(Robot target) {
        List<String> commandList = new ArrayList<>(getCommandHistory());

        // This is n-m (start - end)
        if (this.startRange != -1 && this.endRange != -1) {
            commandList = commandList.subList(commandList.size() - startRange, commandList.size() - endRange);
        }

        // This is n (start)
        else if (this.startRange != -1 ) {
            commandList = commandList.subList(commandList.size() - startRange, commandList.size());
        }
        
        // This is reversed
        if (this.isReversed) {
            Collections.reverse(commandList);
        }

        setCommandReplaying(true);

        for (String command: commandList) {
            Command commandToReplay = Command.create(command);
            target.handleCommand(commandToReplay);
            System.out.println(target);
        }

        setCommandReplaying(false);

        target.setStatus("replayed " + commandList.size() + " commands." );
        return true;
    }
}

