package za.co.wethinkcode.toyrobot;

import za.co.wethinkcode.toyrobot.world.IWorld;

public class SprintCommand extends Command {
    public SprintCommand(String argument) {
        super("sprint", argument);
    }

    @Override
    public boolean execute(Robot target) {
        int nrSteps = Integer.parseInt(getArgument());
        while (nrSteps > 0 && target.world.updatePosition(nrSteps) == IWorld.UpdateResponse.SUCCESS) {
            target.setStatus("Moved forward by " + nrSteps + " steps.");
            if (nrSteps > 1) {
                System.out.println(target);
            }
            nrSteps--;
        }
        if (nrSteps > 0) {
            target.setStatus("Sorry, I cannot go outside my safe zone.");
        }
        return true;
    }


}