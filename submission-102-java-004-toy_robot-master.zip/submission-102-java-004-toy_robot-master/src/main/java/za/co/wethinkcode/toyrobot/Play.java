package za.co.wethinkcode.toyrobot;

import za.co.wethinkcode.toyrobot.maze.EmptyMaze;
import za.co.wethinkcode.toyrobot.maze.Maze;
import za.co.wethinkcode.toyrobot.maze.RandomMaze;
import za.co.wethinkcode.toyrobot.maze.SimpleMaze;
import za.co.wethinkcode.toyrobot.world.*;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Play {
    static Scanner scanner;
    /*
     * The main method of the Play class is responsible for instantiating and controlling the behavior of the robot.
     *
     * Args:
     *     args (String[]): command-line arguments provided to the application
     */
    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        Robot robot;
        AbstractWorld world;
        Maze maze = null;

        // Get the name of the robot from the user
        String name = getInput("What do you want to name your robot?");
        System.out.println("Hello Kiddo!");
        robot = new Robot(name);



        switch (args.length) {
            // They have chosen the world & maze.
            // Create an additional switch case handling the available mazes
            // (i.e. empty maze, simple maze, and random maze)
            // Then call the world constructor with maze as parameter.
            case 2:
                String mazeChoice = args[1].toLowerCase();
//                String mazeChoice = args[1];
                switch (mazeChoice) {
                    case "emptymaze":
//                    case "empty":
                        maze = new EmptyMaze();
                        break;
                    case "simplemaze":
//                    case "simple":
                        maze = new SimpleMaze();
                        break;
                    case "randommaze":
//                    case "random":
                    default:
                        maze = new RandomMaze();
                        break;
                }
                if (Objects.equals(args[0], "turtle")) {
                    world = new TurtleWorld(maze);
                } else {
                    world = new TextWorld(maze);
                }
                robot = new Robot(name);
                break;
            // They have chosen a world but no maze.
            case 1:
                if (Objects.equals(args[0], "turtle")) {
                    world = new TurtleWorld(maze);
                } else {
                    world = new TextWorld();
                }
                robot = new Robot(name);
                break;
            // They chose nothing.
            case 0:
                world = new TextWorld();
                robot = new Robot(name);
                break;
            // If no cases met, default is given eg 3 args or more.
            default:
                System.err.println("Invalid number of arguments.");
                System.exit(1);
        }



//        System.out.println("Loaded " + Arrays.toString(args) + ".");


//        AbstractWorld world1 = new AbstractWorld(null);
//        world1.showObstacles(); // list the obstacles in the world

        Command command;
        boolean shouldContinue = true;


        do {
            // Get the next command from the user
            String inputPrompt = name + "> What must I do next?" ;
            String input = getInput(inputPrompt);
            try {
                command = Command.create(input);
                shouldContinue = robot.handleCommand(command);
            } catch (IllegalArgumentException e) {
                robot.setStatus("Sorry, I did not understand '" + input + "'.");
            }
            System.out.println(robot);
        } while (shouldContinue);
    }

    public static String getInput(String prompt) {
        /*
         * The getInput method is responsible for getting input from the user.
         *
         * Args:
         *     prompt (String): the prompt to display to the user
         *
         * Returns:
         *     String: the input from the user
         */
        System.out.println(prompt);
        String input = scanner.nextLine();

        while (input.isBlank()) {
            System.out.println(prompt);
            input = scanner.nextLine();
        }
        return input;
    }
}
