package za.co.wethinkcode.toyrobot.maze;

import za.co.wethinkcode.toyrobot.Position;
import za.co.wethinkcode.toyrobot.world.IWorld;
import za.co.wethinkcode.toyrobot.world.Obstacle;
import za.co.wethinkcode.toyrobot.world.SquareObstacle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomMaze implements Maze {

    public int x;
    public int y;

    @Override
    public int getBottomLeftX() {
        return this.x;
    }

    @Override
    public int getBottomLeftY() {
        return this.y;
    }

    /**
     * @return the list of obstacles, or an empty list if no obstacles exist.
     */
    @Override
    public List<Obstacle> getObstacles() {
        List<Obstacle> obstacleList = new ArrayList<>();
        Random random = new Random();
        int numObstacles = random.nextInt(10);
        for (int i = 0; i < numObstacles; i++) {
            int x = random.nextInt(IWorld.WIDTH);
            int y = random.nextInt(IWorld.HEIGHT);
            obstacleList.add(new SquareObstacle(x, y));
        }
        return obstacleList;
    }

    @Override
    public boolean blocksPath(Position a, Position b) {
        if (a.getX() == b.getX()) {
            // Moving vertically
            int startY = Math.min(a.getY(), b.getY());
            int endY = Math.max(a.getY(), b.getY());
            for (int y = startY + 1; y < endY; y++) {
                Obstacle obstacle = (Obstacle) this.getObstacles();
                if (obstacle != null) {
                    return true; // obstacle found
                }
            }
        } else if (a.getY() == b.getY()) {
            // Moving horizontally
            int startX = Math.min(a.getX(), b.getX());
            int endX = Math.max(a.getX(), b.getX());
            for (int x = startX + 1; x < endX; x++) {
                Obstacle obstacle = (Obstacle) this.getObstacles();
                if (obstacle != null) {
                    return true; // obstacle found
                }
            }
        }
        return false; // no obstacle found
    }
}
