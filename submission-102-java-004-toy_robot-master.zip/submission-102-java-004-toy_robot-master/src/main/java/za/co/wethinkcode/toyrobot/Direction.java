package za.co.wethinkcode.toyrobot;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
