package za.co.wethinkcode.toyrobot.world;

import za.co.wethinkcode.toyrobot.Position;
import za.co.wethinkcode.toyrobot.maze.Maze;

import java.util.List;


public class TextWorld extends AbstractWorld {

    private static final List<Position> obstacles = null;

    // Default maze
    public TextWorld() {
        super(obstacles);
    }
// With a maze selection.
    public TextWorld(Maze maze) {
        super(obstacles, maze);
    }

    /**
     * Gives opportunity to world to draw or list obstacles.
     */
    @Override
    public void showObstacles() {

    }
}

