package za.co.wethinkcode.toyrobot;

import za.co.wethinkcode.toyrobot.world.IWorld;

public class BackCommand extends Command{

    public BackCommand(String argument) {
        super("back", argument);
    }

    @Override
    public boolean execute(Robot target) {
    int nrSteps = Integer.parseInt(getArgument());
        IWorld.UpdateResponse response = target.updatePosition(-nrSteps);
        switch (response) {
            case SUCCESS:
                target.setStatus("Moved back by " + nrSteps + " steps.");
                break;
            case FAILED_OBSTRUCTED:
                target.setStatus("Sorry, there is an obstacle in the way.");
                break;
            case FAILED_OUTSIDE_WORLD:
                target.setStatus("Sorry, I cannot go outside my safe zone.");
                break;
        }
        return true;
    }

}
