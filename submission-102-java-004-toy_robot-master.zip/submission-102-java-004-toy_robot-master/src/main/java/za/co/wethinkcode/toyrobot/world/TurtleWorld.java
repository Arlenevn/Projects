package za.co.wethinkcode.toyrobot.world;

import za.co.wethinkcode.toyrobot.Position;
import za.co.wethinkcode.toyrobot.maze.Maze;

import java.util.List;

//
public class TurtleWorld extends AbstractWorld {
    private static final Maze obstacles = null;

    public TurtleWorld(Maze maze) {
        super((List<Position>) obstacles);
    }
//    private final Turtle turtle;
//
//    public TurtleWorld(Maze maze) {
//        super(obstacles);
//        turtle = new Turtle(); //Fixme: missing xPos, yPos & angle args
//        turtle.speed(500);
//        turtle.setFillColor(Color.RED);
//        turtle.hideTurtle();
//        drawObstacles();
//    }
//
//    @Override
//    public void showObstacle(Obstacle obstacle) {
//        int x = obstacle.getBottomLeftX() + 2;
//        int y = obstacle.getBottomLeftY() + 2;
//        int size = obstacle.getSize() - 4;
//        turtle.penUp();
//        turtle.setPos(x, y);
//        turtle.penDown();
//        turtle.addSegment(size, 0);
//        turtle.addSegment(0, size);
//        turtle.addSegment(-size, 0);
//        turtle.addSegment(0, -size);
//        turtle.penUp();
//    }
//
//    private void redrawRobot(Position oldPosition, Position newPosition) {
//        int x1 = oldPosition.getX() * 10;
//        int y1 = oldPosition.getY() * 10;
//        int x2 = newPosition.getX() * 10;
//        int y2 = newPosition.getY() * 10;
//        turtle.penUp();
//        turtle.setPos(x1, y1);
//        turtle.penDown();
//        turtle.setPos(x2, y2);
//    }
//
//
//    @Override
//    public void reset() {
//        turtle.clear();
//        drawObstacles();
//    }//TODO: reset everything manually (position, direction and all obstacles as well as the world)
//
//    private void drawObstacles() {
//        Obstacle[] obstacles = new Obstacle[0];
//        for (Obstacle obstacle : obstacles) {
//            showObstacle(obstacle);
//        }
//    }
}
