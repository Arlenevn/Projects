package za.co.wethinkcode.toyrobot.world;

import za.co.wethinkcode.toyrobot.Position;
import za.co.wethinkcode.toyrobot.maze.EmptyMaze;
import za.co.wethinkcode.toyrobot.maze.Maze;

import java.util.List;


public class AbstractWorld implements IWorld{

    private final Position TOP_LEFT = new Position(-100, 200);
    private final Position BOTTOM_RIGHT = new Position(200, -100);
    private Position position;
    private Direction currentDirection;
    private final List<Position> obstacles;

    private Maze maze;

    //My default constructor.
    public AbstractWorld(List<Position> obstacles){
        this.obstacles = obstacles;

        this.currentDirection = Direction.UP;
        this.position = CENTRE;
        this.maze = new EmptyMaze();

    }
    //Chosen Maze.
    public AbstractWorld(List<Position> obstacles, Maze maze) {
        this.obstacles = obstacles;
        this.maze = maze;
        this.position = CENTRE;
        this.currentDirection = Direction.UP;
    }
    /**
     * Updates the position of your robot in the world by moving the nrSteps in the robots current direction.
     *
     * @param nrSteps steps to move in current direction
     * @return SUCCESS if this does not take the robot over the world's limits, or into an obstacle.
     */
    @Override
    public UpdateResponse updatePosition(int nrSteps) {
        boolean response;
        Position newPosition;
        int newX = this.position.getX();
        int newY = this.position.getY();

        switch (currentDirection) {
            case UP:
                newY += nrSteps;
                break;
            case RIGHT:
                newX += nrSteps;
                break;
            case DOWN:
                newY -= nrSteps;
                break;
            case LEFT:
                newX -= nrSteps;
                break;
        }
        newPosition = new Position(newX, newY);
        response = isNewPositionAllowed(newPosition);

        if (!newPosition.isIn(TOP_LEFT,BOTTOM_RIGHT)) {
            return UpdateResponse.FAILED_OUTSIDE_WORLD;
        } else if (!response) {
            return UpdateResponse.FAILED_OBSTRUCTED;
        }
        this.position = newPosition;
        return UpdateResponse.SUCCESS;
    }

    /**
     * Updates the current direction your robot is facing in the world by cycling through the directions UP, RIGHT, BOTTOM, LEFT.
     *
     * @param turnRight if true, then turn 90 degrees to the right, else turn left.
     */
    public void updateDirection(boolean turnRight) {
        if (turnRight) {
            switch (currentDirection) {
                case UP:
                    currentDirection = Direction.RIGHT;
                    break;
                case RIGHT:
                    currentDirection = Direction.DOWN;
                    break;
                case DOWN:
                    currentDirection = Direction.LEFT;
                    break;
                case LEFT:
                    currentDirection = Direction.UP;
                    break;
            }
        } else {
            switch (currentDirection) {
                case UP:
                    currentDirection = Direction.LEFT;
                    break;
                case LEFT:
                    currentDirection = Direction.DOWN;
                    break;
                case DOWN:
                    currentDirection = Direction.RIGHT;
                    break;
                case RIGHT:
                    currentDirection = Direction.UP;
                    break;
            }
        }
    }

    /**
     * Retrieves the current position of the robot
     */
    public Position getPosition() {
        return position;
    }

    /**
     * Gets the current direction the robot is facing in relation to a world edge.
     *
     * @return Direction.UP, RIGHT, DOWN, or LEFT
     */
    public Direction getCurrentDirection() {
        return currentDirection;
    }

    /**
     * Checks if the new position will be allowed,
     * i.e. falls within the constraints of the world,
     * and does not overlap an obstacle.
     *
     * @param position the position to check
     * @return SUCCESS if it is allowed, else false
     */
    public boolean isNewPositionAllowed(Position position) {
        //Obstacle
        if (position.getX() < -100 || position.getX() > 100
                || position.getY() < -200 || position.getY() > 200) {
            return false;
        }
// Check if the new position overlaps with any of the obstacles
        if (obstacles != null) {
            for (Position obstacle : obstacles) {
                if (obstacle.equals(position)) {
                    return false;
                }
            }
        }
        return true;
    }






        /**
         * Checks if the robot is at one of the edges of the world
         *
         * @return true if the robot's current is on one of the 4 edges of the world
         */
    public boolean isAtEdge() {
        return position.getX() == TOP_LEFT.getX() || position.getX() == BOTTOM_RIGHT.getX() ||
                position.getY() == TOP_LEFT.getY() || position.getY() == BOTTOM_RIGHT.getY();
    }

    /**
     * Reset the world by:
     * - moving current robot position to center 0,0 coordinate
     * - removing all obstacles
     * - setting current direction to UP
     */
    public void reset() {
        this.position = CENTRE;
        this.maze = new EmptyMaze();
        this.currentDirection = Direction.UP;
    }


    /**
     * Gives opportunity to world to draw or list obstacles.
     */
    public void showObstacles() {
        for (Obstacle obstacle : maze.getObstacles()) {
            System.out.println(obstacle.toString());
        }
    }
}

