package za.co.wethinkcode.toyrobot.world;

import za.co.wethinkcode.toyrobot.Position;

/**
 * Represents a square obstacle in a toy robot world.
 */

public class SquareObstacle implements Obstacle {

    private final int x;
    private final int y;
    private final int size = 5;


    public SquareObstacle(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public int getBottomLeftX() {
        return x;
    }

    @Override
    public int getBottomLeftY() {
        return y;
    }

    @Override
    public int getSize() {
        return size;
    }

    /**
     * We need to check if the given position is in this obstacle.
     * @param position the given position to check
     */
    @Override
    public boolean blocksPosition(Position position) {

        Position topLeft = new Position(this.x, this.y + this.size - 1);
        Position bottomRight = new Position(this.x + size - 1, this.y);
        return position.isIn(topLeft, bottomRight);
    }

    /**
     * Check if this obstacle blocks position for any position between the two
     * positions given.
     * @param a first position
     * @param b second position
     */
    @Override
    public boolean blocksPath(Position a, Position b) {

        int aX = a.getX();
        int aY = a.getY();
        int bX = b.getX();
        int bY = b.getY();

        if (aX == bX) {
            int minY = Math.min(aY, bY);
            int maxY = Math.max(aY, bY);
            return aX >= x && aX < x + size && minY < y + size && maxY >= y;
        } else if (aY == bY) {
            int minX = Math.min(aX, bX);
            int maxX = Math.max(aX, bX);
            return aY >= y && aY < y + size && minX < x + size && maxX >= x;
        } else {
            // diagonal movement not supported yet
            return true;
        }
    }
}
