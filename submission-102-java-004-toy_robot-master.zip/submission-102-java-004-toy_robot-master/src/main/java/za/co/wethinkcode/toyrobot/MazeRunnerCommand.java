package za.co.wethinkcode.toyrobot;

import za.co.wethinkcode.toyrobot.world.AbstractWorld;
import za.co.wethinkcode.toyrobot.world.IWorld;

public class MazeRunnerCommand extends Command {



    public MazeRunnerCommand(String argument) {
        super("mazerun", argument);
    }
    @Override
    public boolean execute(Robot target) {
        target.updatePosition(200);
        target.setStatus("I am at the top edge. (Cost: 2 steps)");
        return true;
    }
}
