
#STEP ONE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_outline():
    #create a set that contains these topics, and then print each item in the list, under the heading Course Topics.
    print ("Course Topics:")
    course_topics = {"Introduction to Python", "Tools of the Trade", "How to make decisions", "How to repeat code", "How to structure data", "Functions", "Modules"}
    course = list(course_topics)
    course_list = sorted(course_topics)
    for course in course_list:
        print ("*", course)
#STEP TWO ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#assume each topic has three problems: Problem 1, Problem 2 and Problem 3
    problems = ["Problem 1,", "Problem 2,", "Problem 3"]
    topics = map(str, problems)
    work = " ".join(topics)
    print ("Problems:")
    
    for topic in course_list:
        # print("* " + topic":" + work)
        print(f"* {topic} : {work}")
#STEP THREE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Use a tuple that combines: * a student name * a topic name * a problem * a status, e.g. STARTED, GRADED or COMPLETED 
    print ("Student Progress:")
    student = [("Blossom", "Bubbles", "Buttercup"), 
    ("Tools of the Trade","How to make decisions", "Introduction to Python"), 
    ("problem 1", "problem 2", "problem 3"), 
    ("STARTED", "GRADED", "COMPLETED")]

    print(f"1. {student[0][0]} - {student[1][0]} - {student[2][0]} - [{student[3][0]}]")
    print(f"2. {student[0][1]} - {student[1][1]} - {student[2][1]} - [{student[3][1]}]")
    print(f"3. {student[0][2]} - {student[1][2]} - {student[2][2]} - [{student[3][2]}]")


if __name__ == "__main__":
    create_outline()
    
   
    

 



    #doubled_numbers = list((lambda item: double(item), numbers))
    # doubled = list(map(lambda x:2*x, numbers))
    # doubled = list(map(lambda x:double(x), numbers))
    # print(doubled)

    


