#TIP: use random.randint to get a random word from the list
import random

def read_file(file_name):
    """
    TODO: Step 1 - open file and read lines as words
    """
    w = open(file_name, 'r')
    words = w.readlines()  
    w.close()

    return words

def select_random_word(words):
    """
    TODO: Step 2 - select random word from list of file
    """
    #Select a random word from the list of words 
    random_word_index = random.randint(0, len(words) - 1)
    computer_word = words[random_word_index].strip()
    #Select a random letter from the word, which is the one the player will have to guess
    random_letter_index = random.randint(0, len(computer_word)-1)
    computer_letter = computer_word[random_letter_index]
    #Display the word, but show a _ instead of the selected letter.
    new_word = computer_word.replace(computer_letter, "_", 1)



    # return words[0]
    print ('Guess the word: '+new_word)
    return computer_word

def get_user_input():
    """
    TODO: Step 3 - get user input for answer
    """
    user_input = input("\nGuess the missing letter: ")
    return user_input


def run_game(file_name):
    """
    This is the main game code. You can leave it as is and only implement steps 1 to 3 as indicated above.
    """
    words = read_file(file_name)
    word = select_random_word(words)
    answer = get_user_input()
    print('The word was: '+word)


if __name__ == "__main__":
    run_game('short_words.txt')

