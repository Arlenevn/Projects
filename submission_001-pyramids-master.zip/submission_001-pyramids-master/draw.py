

# TODO: Step 1 - get shape (it can't be blank and must be a valid shape!)
from operator import truediv


def get_shape():
    List = ['pyramid', 'square', 'triangle', 'diamond', 'hourglass', 'rectangle']
    user_input = input("Shape?: ").lower()
    while user_input not in List:
        user_input = input ("Shape?:").lower()
    return user_input


# TODO: Step 1 - get height (it must be int!)
def get_height():
    user_input = input('Height?: ')
    while user_input.isalpha(): 
        user_input = input ('Height?:')
    if int(user_input) <80:
        return int(user_input) 
    else: 
        get_height() 


# TODO: Step 2
def draw_pyramid(height, outline):
    if outline == True:
        #outline *********************************************
        for i in range(height):
            for j in range(height-i-1):
                print(' ', end='')
            for j in range(2*i+1):
                if j == 0 or j == 2*i or i == height-1:
                    print('*', end='')
                else:
                    print(' ', end='')
            print()

    else: #solid**********************************************
        for i in range (1, height + 1):
            for j in range (1, height +1 - i):
                    print (' ', end = '')
            for k in range (1,(2*i)):
                print ('*', end='')
            print()


# TODO: Step 3
def draw_square(height, outline):
    if outline == True:
        #outline************************************************
        for i in range(1,height+1):
            for j in range(1,height+1):
                if i == 1 or i == height or j == 1 or j == height:
                    print('*', end = '')
                else:
                    print(' ', end='')
            print()

    else: #solid************************************************
        i = 0
        while(i < height):
            j = 0
            while(j < height):      
                j = j + 1
                print('*', end = '')
            i = i + 1
            print()
    
# TODO: Step 4
def draw_triangle(height, outline):
    if outline == True: 
        #outline********************************************************
        for i in range(height):
            for j in range(i+1):
                if (j== 0 or j==i or i==height-1):
                    print('*', end='')
                else:
                    print(' ', end='')
            print()
    else: #solid*********************************************************
        i =1 
        while (i <= height):
            j = 1
            while (j <= i):
                j = j +1
                print ('*', end = '')
            i = i + 1
            print()
        #print()

def draw_rectangle(height, outline): 
    coloumn = height*4 #outline**************************************
    for i in range(1, height+1):
            for j in range(1, coloumn+1):
                if i == 1 or i == height or j == 1 or j == coloumn:
                    print("*", end="")
                else:
                    print(" ", end='')
            print()
            
    for i in range(1, height+1): #solid**************************************
        for j in range(1,coloumn+1):
            print('*', end='')
        print()

def draw_diamond(height, outline):
    if outline == True:
        #outline************************************************
        for i in range(1, height-i+1):
            print(' ', end='')
            for j in range(1,2*i):
                if j == 1 or j == 2*i-1:
                    print('*', end='')
                else:
                    print(' ', end='')
        
        for i in range(height-1,0,-1):
            for j in range(1, height-i +1):
                print(' ', end='')
            for j in range(1, 2*i):
                if j == 1 or j == 2*i-1:
                    print('*', end='')
                else:
                    print(' ', end='')
        print()

    else: #solid****************************************************
        for i in range (1, height +1):
            for j in range(1,(height*2)-i+1):
                print(' ', end='')
            for j in range(1, 2*i):
                print('*', end='')
            print()

        for i in range(height-1, 0, -1):
            for j in range(1,(height*2)-i+1):
                print(' ', end='')
            for j in range(1,2*i):
                print('*', end='')
            print()
    
def draw_hourglass(height, outline):
    if outline == True:
        #oultine********************************************
        for i in range(height, 0, -1):
            for j in range(height-i):
                print(' ', end='')
            for j in range(1, 2*i):
                if i==1 or i ==height or j ==1 or j==2*i-1:
                    print('*', end='')
                else:
                    print(' ', end='')
            print()

        for i in range (2, height+1):
            for j in range(height-i):
                print(' ', end='')
            for j in range(1, 2*i):
                if i==1 or i==height or j==1 or j==2*i-1:
                    print('*', end='')
                else:
                    print(' ', end='')
            print()
    else: #solid*****************************************************
        for i in range(height,0, -1):
            for j in range(height-i):
                print(' ', end='')
            for j in range(1,2*i):
                print('*', end='')
            print()

        for i in range(2,height+1):
            for j in range(height-i):
                    print(' ', end='')
            for j in range(1,2*i):
                    print('*', end='')
            print()

    
# TODO: Steps 2 to 4, 6 - add support for other shapes
def draw(shape, height, outline): 
    if shape == "pyramid":
        draw_pyramid(height, outline)
    elif shape == "square":
        draw_square(height, outline)
    elif shape == 'triangle':
        draw_triangle(height, outline)
    elif shape == "rectangle":
        draw_rectangle(height, outline)
    elif shape == "diamond":
        draw_diamond(height, outline)
    elif shape == "hourglass":
        draw_hourglass(height, outline)


# TODO: Step 5 - get input from user to draw outline or solid
def get_outline():
    true = input("outline?(y/N):")
    if true == "y":
        return True
    else:
        return False
    


if __name__ == "__main__":
    shape_param = get_shape()
    height_param = get_height()
    outline_param = get_outline()
    draw(shape_param, height_param, outline_param)

