package wethinkcode.web;

import com.google.common.annotations.VisibleForTesting;
import io.javalin.Javalin;
import io.javalin.plugin.rendering.template.JavalinThymeleaf;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import kong.unirest.json.JSONArray;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import wethinkcode.StageDO;

import java.util.Map;

/**
 * I am the front-end web server for the LightSched project.
 * <p>
 * Remember that we're not terribly interested in the web front-end part of this
 * server, more in the way it communicates and interacts with the back-end
 * services.
 */
public class WebService
{

    public static final int DEFAULT_PORT = 80;
    private static final String TEMPLATES_DIR = "/templates/";
    private Javalin server;
    private int servicePort;

    public static void main( String[] args ){
        JavalinThymeleaf.configure(templateEngine());
        final WebService svc = new WebService().initialise();
        svc.start();
    }

    @VisibleForTesting
    WebService initialise(){
        // TODO: add http client and server configuration here
        this.server = configureHttpServer();
        configureHttpClient();
        return this;
    }

    public void start(){
        start( DEFAULT_PORT );
    }

    @VisibleForTesting
    void start( int networkPort ){
        servicePort = networkPort;
        run();
    }

    public void stop(){
        server.stop();
    }

    public void run(){
//        server.start( servicePort );
    }

    private void configureHttpClient(){
        String serverUrl = "http://localhost:7000";

        //handler to fetch provinces
        server.get("/provinces", ctx -> {
            // Make an HTTP GET request to the server and retrieve provinces data
            JsonNode response = Unirest.get(serverUrl + "/provinces").asJson().getBody();

            //Extract relevant data
            String provinces = response.toString();

            // create a data model and pass to template
            Map<String, Object> viewModel = Map.of("provinces", provinces);
            ctx.render("provinces.html", viewModel);
        } );

        server.get("/towns/{province}", ctx -> {
            String selectedProvince = ctx.pathParam("province");

            JsonNode response = Unirest.get(serverUrl + "/towns/" + selectedProvince).asJson().getBody();

            String towns = response.toString();

            Map<String, Object> viewModel = Map.of("towns", towns, "selectedProvince", selectedProvince);
            ctx.render("towns.html", viewModel);
        } );

        server.get("/schedule/{town}", ctx -> {
            String selectedTown = ctx.pathParam("town");
            //Make HTTP GET request
            JsonNode response = Unirest.get(serverUrl + "/schedule/" + selectedTown).asJson().getBody();
            //Extract data
            String schedule = response.toString();

            // create data model and pass it to the template
            Map<String, Object> viewModel = Map.of("schedule", schedule, "selectedTown", selectedTown);
            ctx.render("schedule.html", viewModel);

        } );

    }

    private Javalin configureHttpServer(){
        String serverUrl = "http://localhost:7000";
        Javalin createApp = Javalin.create().start();
        createApp.get("/", ctx -> {
            // Make an HTTP GET request to the server and retrieve provinces data
            HttpResponse<JsonNode> response = Unirest.get( serverUrl + "/provinces" ).asJson();

            //Extract relevant data
            JSONArray provinces = response.getBody().getArray();

            String stage = String.valueOf(StageDO.getStage());

            // create a data model and pass to template
            Map<String, Object> viewModel = Map.of("provinces", provinces,
                    "stage" , stage);
            //serve index page to the client
            String homePage = "index.html";
            ctx.render(homePage, viewModel);
        } );

        createApp.post("/schedule", ctx -> {
            // handle submission and fetch schedule data
            String selectedProvince = ctx.formParam("province");
            String selectedTown = ctx.formParam("town");

            // fetch schedule data based on selected province and town
            JsonNode response = Unirest.get(serverUrl + "/schedule/" + selectedTown).asJson().getBody();
            String schedule = response.toString();

            // create data model and pass it to the template
            Map<String, Object> viewModel = Map.of("schedule", schedule, "selectedTown", selectedTown);
            ctx.render("schedule.html", viewModel);
        } );
        return createApp;
    }

    private static TemplateEngine templateEngine() {
        TemplateEngine templateEngine = new TemplateEngine();
        ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
        resolver.setPrefix(TEMPLATES_DIR);
        templateEngine.setTemplateResolver(resolver);
        return templateEngine;
    }
}
