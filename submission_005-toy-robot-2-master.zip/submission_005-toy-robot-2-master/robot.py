def robot_start():
    """This is the entry function, do not change"""
    robot_name = get_name()
    run_game(robot_name)


def get_name():

    robot_name = input("What do you want to name your robot? ")

    print (robot_name.upper() + ": Hello kiddo!")

    return robot_name.upper()


def get_command(robot_name):
    
    command_input = input(robot_name + ": What must I do next? ").lower()

    validation_result = validate_command(command_input, robot_name)

    while validation_result == "No":
        command_input = input(robot_name + ": What must I do next? ").lower()
        validation_result = validate_command(command_input, robot_name)

    return command_input


def validate_command(command_input, robot_name):

    command_input_list = command_input.split()

    valid_one_word_commands = ["off", "help", "right", "left"]
    valid_two_word_commands = ["forward", "back", "sprint"]   

    if len(command_input_list) == 1 and command_input in valid_one_word_commands:
        return "Yes" 

    elif len(command_input_list) == 2 and command_input_list[1].isdigit() and command_input_list[0] in valid_two_word_commands:
        return "Yes"

    else: 
        print (robot_name + ": Sorry, I did not understand " + "'" + command_input.capitalize()  + "'.")
        return "No"


def run_game(robot_name):
    
    x = 0 
    y = 0
    quadrant = 0

    
    keep_going = True

    while keep_going == True:
        command = get_command(robot_name)
        x, y, quadrant, keep_going = execute_command(x, y, quadrant, command, robot_name, keep_going)
    exit


def execute_command(x, y, quadrant, command, robot_name, keep_going):

    command_input_list = command.split()

    if len(command_input_list) == 1:
        action = command_input_list[0]
        if action == "off":
            off_command(robot_name)
            keep_going = False
        elif action == "left":
            quadrant = left_command(x, y, quadrant, robot_name)
        elif action == "right":
            quadrant = right_command(x, y, quadrant, robot_name)
        elif action == "help":
            help_command(robot_name)
        

    elif len(command_input_list) == 2:
        action = command_input_list[0]
        steps = command_input_list[1]
        steps = int(steps)
        if action == "forward": 
            x, y = forward_command(x, y, quadrant, steps, robot_name)
        elif action == "back":
            x, y = back_command(x, y, quadrant, steps, robot_name)
        elif action == "sprint":
            x, y = sprint_command(x, y, quadrant, steps, robot_name)

    if action == "help" or action == "off": 
        return x, y, quadrant, keep_going
    elif action != "help" or action != "off":
        print (" > " + robot_name + " now at position " + "(" + str(x) + "," + str(y) + ").")

    return x, y, quadrant, keep_going


def off_command(robot_name):
    print (robot_name + ": Shutting down..")
    exit


def help_command(robot_name):

    print("""I can understand these commands:
OFF  - Shut down robot
HELP - provide information about commands
FORWARD + number of forward movements(i.e 'Forward 10') - Move robot forward
BACK + number of backward movements(i.e 'Back 10') - Move robot back
RIGHT - Right-turn(turn robot by 90 degrees to the right)
LEFT - Left-turn(turn robot by 90 degrees to the left)
SPRINT - Gives robot a short burst of speed and some extra distance
""")


def forward_command(x, y, quadrant, steps, robot_name):

    default_x_value = x
    default_y_value = y


    if quadrant == 0: 
            y += steps
    elif quadrant == 1 or quadrant == -3:
            x += steps
    elif quadrant == 2 or quadrant == -2: 
            y -= steps 
    elif quadrant == 3 or quadrant == -1:
            x -= steps

    if (y >200 or y < -200) or (x >100 or x < -100):
        print (robot_name + ": Sorry, I cannot go outside my safe zone.")
        return default_x_value, default_y_value
    else:
        print (" > " + robot_name + " moved forward by " + str(steps) + " steps.") 
        return x, y  


def back_command(x, y, quadrant, steps, robot_name):

    default_x_value = x
    default_y_value = y

    if quadrant == 0: 
        y -= steps
    elif quadrant == 1 or quadrant == -3:
        x -= steps
    elif quadrant == 2 or quadrant == -2: 
        y += steps 
    elif quadrant == 3 or quadrant == -1:
        x += steps

    if (y >200 or y < -200) or (x >100 or x < -100):
        print (robot_name + ": Sorry, I cannot go outside my safe zone.")
        return default_x_value, default_y_value
    else:
        print (" > " + robot_name + " moved back by " + str(steps) + " steps.") 
        return x, y


def right_command(x, y, quadrant, robot_name):
    
    quadrant += 1
    
    print (" > " + robot_name + " turned right.") 

    return quadrant


def left_command(x, y , quadrant, robot_name):
    
    quadrant -= 1

    print (" > " + robot_name + " turned left.") 
    
    return quadrant


def sprint_command(x, y, quadrant, steps, robot_name):

    default_x_value = x
    default_y_value = y

    if steps == 0: 
        return x,y 
    else: 
        x, y = forward_command (x, y, quadrant, steps, robot_name)
        steps -= 1 

        if (y >200 or y < -200) or (x >100 or x < -100):
            return default_x_value, default_y_value
        
    return sprint_command (x, y, quadrant, steps, robot_name)


if __name__ == "__main__":
    robot_start()
    