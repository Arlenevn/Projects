package weshare.model;

/*
 ** DO NOT CHANGE!!
 */


public class WeShareException extends RuntimeException {
    public WeShareException(String message) {
        super(message);
    }
}
