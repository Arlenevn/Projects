package weshare.controller;

import io.javalin.http.Handler;
import org.javamoney.moneta.Money;
import weshare.model.DateHelper;
import weshare.model.Expense;
import weshare.model.MoneyHelper;
import weshare.model.Person;
import weshare.persistence.ExpenseDAO;
import weshare.server.Routes;
import weshare.server.ServiceRegistry;
import weshare.server.WeShareServer;

import javax.money.Monetary;
import javax.money.MonetaryAmount;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.*;

import static weshare.server.Routes.EXPENSES;


public class ExpensesController {

    public static final Handler view = context -> {
        ExpenseDAO expensesDAO = ServiceRegistry.lookup(ExpenseDAO.class);
        Person personLoggedIn = WeShareServer.getPersonLoggedIn(context);

        Collection<Expense> expenses = expensesDAO.findExpensesForPerson(personLoggedIn);
        Collection<Expense> expenseList = new ArrayList<>();
        MonetaryAmount expense_total = MoneyHelper.ZERO_RANDS;
        for (Expense expense : expenses) {
            if(!expense.isFullyPaidByOthers()) {
                expenseList.add(expense);
            }
            expense_total = expense_total.add(expense.getAmount());
        }
        Map<String, Object> viewModel = Map.of("expenses", expenseList,
                "expense_total", expense_total);
        context.render("expenses.html", viewModel);
    };

    public static Handler addExpense = context -> {
        // Retrieve data from the form submission
        String expenseName = context.formParam("description");
        double expenseAmount = Double.parseDouble(context.formParam("amount"));
        String expenseDate = context.formParam("date");

        // create a new Expense object using the form data
        Expense newExpense = new Expense(
                WeShareServer.getPersonLoggedIn(context),
                expenseName,
                Money.of(expenseAmount, Monetary.getCurrency("ZAR")),
                LocalDate.parse(expenseDate, DateHelper.DD_MM_YYYY)
        );

        //Save new expense
        ExpenseDAO expenseDAO = ServiceRegistry.lookup(ExpenseDAO.class);
        expenseDAO.save(newExpense);

        // redirect back to the expenses view
        context.redirect(EXPENSES);
    };

    public static Handler form = context -> {
        ExpenseDAO expenseDAO = ServiceRegistry.lookup(ExpenseDAO.class);

        int amount = context.formParamAsClass("amount", Integer.class)
                .check(Objects::nonNull, "Amount is required")
                .get();

        String date = context.formParamAsClass("date", String.class)
                .check(Objects::nonNull, "Date is required")
                .get();

        LocalDate localDate = LocalDate.parse(date, DateHelper.DD_MM_YYYY);

        Expense expense = new Expense(WeShareServer.getPersonLoggedIn(context),
                context.formParam("description"),
                Money.of(amount, "ZAR"),
                localDate);

        expenseDAO.save(expense);

        context.redirect(Routes.EXPENSES);
    };
}
