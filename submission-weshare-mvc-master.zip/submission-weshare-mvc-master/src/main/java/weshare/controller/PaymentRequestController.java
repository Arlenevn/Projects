package weshare.controller;
import io.javalin.http.Handler;
import org.javamoney.moneta.Money;
import weshare.model.*;
import weshare.model.Person;
import weshare.persistence.ExpenseDAO;
import weshare.persistence.PersonDAO;
import weshare.server.Routes;
import weshare.server.ServiceRegistry;
import weshare.server.WeShareServer;

import javax.money.Monetary;
import javax.money.MonetaryAmount;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

import static weshare.server.Routes.PAYMENT_REQUEST_FORM;
public class PaymentRequestController {
    public static final Handler displayPaymentRequestForm = context -> {
        ExpenseDAO expenseDAO = ServiceRegistry.lookup(ExpenseDAO.class);

        String expenseId = context.queryParam("expenseId");
        UUID id = UUID.fromString(expenseId);
        Optional<Expense> Expense = expenseDAO.get(id);

        Collection<PaymentRequest> expense = Expense.get().listOfPaymentRequests();

        String description = Expense.get().getDescription();
        LocalDate date = Expense.get().getDate();
        MonetaryAmount amount = Expense.get().getAmount();;

        MonetaryAmount amountToPay = MoneyHelper.ZERO_RANDS;
        Map<String, Object> viewModel;

        if (expense.size() > 0) {
            viewModel = Map.of("paymentRequest", expense,
                    "payments_total", amountToPay,
                    "description", description,
                    "date", date,
                    "amount", amount,
                    "expense", Expense.get());
        } else {
            viewModel = Map.of("description", description,
                    "date", date,
                    "amount", amount);
        }
        context.render("paymentrequest.html", viewModel);
    };

    public static final Handler submitPaymentRequestForm = context -> {

        PersonDAO personDAO = ServiceRegistry.lookup(PersonDAO.class);
        ExpenseDAO expenseDAO = ServiceRegistry.lookup(ExpenseDAO.class);

        String email = context.formParamAsClass("email", String.class)
                .check(Objects::nonNull, "Email is required")
                .get();

        Person person = new Person(email);
        Stream.of(person).forEach(personDAO::savePerson);

        int amount = context.formParamAsClass("amount", Integer.class)
                .check(Objects::nonNull, "Email is required")
                .get();

        String date = context.formParamAsClass("due_date", String.class)
                .check(Objects::nonNull, "Date is required")
                .get();

        LocalDate localDate = LocalDate.parse(date, DateHelper.DD_MM_YYYY);

        String id = context.formParamAsClass("id", String.class)
                .check(Objects::nonNull, "Id is required")
                .get();

        UUID uuid = UUID.fromString(id);
        Optional<Expense> Expense = expenseDAO.get(uuid);
        Expense expense = Expense.get().requestPayment(person, Money.of(amount, "ZAR"), localDate).getExpense();

        context.redirect(PAYMENT_REQUEST_FORM + "?expenseId=" + id);

    };
}

