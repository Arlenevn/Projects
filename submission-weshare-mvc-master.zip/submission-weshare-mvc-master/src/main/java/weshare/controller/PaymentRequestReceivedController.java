package weshare.controller;

import io.javalin.http.Handler;
import org.javamoney.moneta.Money;
import weshare.model.*;
import weshare.model.Person;
import weshare.persistence.ExpenseDAO;
import weshare.persistence.PersonDAO;
import weshare.server.Routes;
import weshare.server.ServiceRegistry;
import weshare.server.WeShareServer;

import javax.money.Monetary;
import javax.money.MonetaryAmount;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

import static weshare.server.Routes.PAYMENT_REQUESTED_RECEIVED;

public class PaymentRequestReceivedController {

    public static final Handler displayPaymentsReceivedForm = context -> {
        ExpenseDAO expensesDAO = ServiceRegistry.lookup(ExpenseDAO.class);
        Person personLoggedIn = WeShareServer.getPersonLoggedIn(context);

        Collection<PaymentRequest> requests = expensesDAO.findPaymentRequestsReceived(personLoggedIn);

        MonetaryAmount expense_total = MoneyHelper.ZERO_RANDS;
        for (PaymentRequest paymentRequest : requests) {
            if (!paymentRequest.isPaid()) {
                expense_total = expense_total.add(paymentRequest.getAmountToPay());
            }
        }

        Map<String, Object> viewModel = Map.of("payments", requests,
                "grand_total", expense_total);

        context.render("paymentrequests_received.html", viewModel);
    };
    //post hidden form which is the pay button using payment.action
    // New method for processing payments via POST
    public static final Handler processPayment = context -> {

        ExpenseDAO expenseDAO = ServiceRegistry.lookup(ExpenseDAO.class);
        Person personLoggedIn = WeShareServer.getPersonLoggedIn(context);

        String id = context.formParamAsClass("expenseId", String.class)
                .check(Objects::nonNull, "ExpenseId is required")
                .get();

        UUID expenseId = UUID.fromString(id);

        String paymentRequestId = context.formParamAsClass("paymentRequestId", String.class)
                .check(Objects::nonNull, "Payment RequestId is required")
                .get();

        UUID requestId = UUID.fromString(paymentRequestId);

        Optional<Expense> expense = expenseDAO.get(expenseId);

        Payment payment = expense.get().payPaymentRequest(requestId, personLoggedIn, DateHelper.TODAY);
        Expense newExpense = new Expense(personLoggedIn, payment.getExpenseForPersonPaying().getDescription(), payment.getAmountPaid(), payment.getPaymentDate());

        expenseDAO.save(expense.get());
        expenseDAO.save(newExpense);
        context.redirect(Routes.PAYMENT_REQUESTED_RECEIVED);
    };
}