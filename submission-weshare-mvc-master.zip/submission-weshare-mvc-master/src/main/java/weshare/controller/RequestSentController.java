package weshare.controller;

import io.javalin.http.Handler;
import weshare.model.MoneyHelper;
import weshare.model.PaymentRequest;
import weshare.model.Person;
import weshare.persistence.ExpenseDAO;
import weshare.server.ServiceRegistry;
import weshare.server.WeShareServer;

import javax.money.MonetaryAmount;
import java.util.*;

public class RequestSentController {

    public static final Handler view = ctx -> {
        ExpenseDAO expensesDAO = ServiceRegistry.lookup(ExpenseDAO.class);
        Person personLoggedIn = WeShareServer.getPersonLoggedIn(ctx);

        Collection<PaymentRequest> requests = expensesDAO.findPaymentRequestsSent(personLoggedIn);

        MonetaryAmount expense_total = MoneyHelper.ZERO_RANDS;
        for (PaymentRequest paymentRequest : requests) {
            expense_total = expense_total.add(paymentRequest.getAmountToPay());
        }

        Map<String, Object> viewModel = Map.of("payments" , requests,
                "grand_total", expense_total);

        ctx.render("paymentrequests_sent.html", viewModel);
    };

}
