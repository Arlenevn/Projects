package weshare.server;

import weshare.controller.*;

import static io.javalin.apibuilder.ApiBuilder.get;
import static io.javalin.apibuilder.ApiBuilder.post;

public class Routes {
    public static final String LOGIN_PAGE = "/";
    public static final String LOGIN_ACTION = "/login.action";
    public static final String LOGOUT = "/logout";
    public static final String EXPENSES = "/expenses";
    public static final String ADD_EXPENSE = "/expense.action"; //Existing route

    public static final String EXPENSE_FORM = "/newexpense"; //New route

    public static final String PAYMENT_REQUEST_FORM="/paymentrequest";
    public static final String PAYMENT_REQUEST_FORM_SUBMIT = "/paymentrequest.action";

    public static final String PAYMENT_REQUESTED_RECEIVED = "/paymentrequests_received";

    public static final String PAYMENT_REQUEST_SENT = "/paymentrequests_sent";

    public static void configure(WeShareServer server) {
        server.routes(() -> {
            post(LOGIN_ACTION,  PersonController.login);
            get(LOGOUT,         PersonController.logout);
            get(EXPENSES,           ExpensesController.view);
            // route for accessing the expense form
            get(EXPENSE_FORM, ExpensesController.form);
            //  route for adding expenses
            post(ADD_EXPENSE, ExpensesController.addExpense);
            // route for displaying the payment request form
            get(PAYMENT_REQUEST_FORM,  PaymentRequestController.displayPaymentRequestForm);
            post(PAYMENT_REQUEST_FORM_SUBMIT, PaymentRequestController.submitPaymentRequestForm);

            get(PAYMENT_REQUESTED_RECEIVED, PaymentRequestReceivedController.displayPaymentsReceivedForm);
            post(PAYMENT_REQUESTED_RECEIVED, PaymentRequestReceivedController.processPayment);

            get(PAYMENT_REQUEST_SENT, RequestSentController.view);
        });
    }
}
