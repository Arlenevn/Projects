package wethinkcode.web;

import io.javalin.Javalin;
import io.javalin.http.Context;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;

public class ApiService {

    public static final String SERVER_URL = "http://localhost:7000";

    public static void main(String[] args) {
        Javalin app = Javalin.create().start(7001);

        // Define an endpoint to get provinces
        app.get("/provinces", ApiService::getProvinces);

        // Define an endpoint to get towns based on a selected province
        app.get("/towns/:province", ApiService::getTowns);

        // Define an endpoint to get schedule based on selected town
        app.get("/schedule/:town", ApiService::getSchedule);
    }

    private static void getProvinces(Context ctx) {
        HttpResponse<JsonNode> response = Unirest.get(SERVER_URL + "/provinces").asJson();
        ctx.json(response.getBody().toString());
    }

    private static void getTowns(Context ctx) {
        String selectedProvince = ctx.pathParam("province");
        HttpResponse<JsonNode> response = Unirest.get(SERVER_URL + "/towns/" + selectedProvince).asJson();
        ctx.json(response.getBody().toString());
    }

    private static void getSchedule(Context ctx) {
        String selectedTown = ctx.pathParam("town");
        HttpResponse<JsonNode> response = Unirest.get(SERVER_URL + "/schedule/" + selectedTown).asJson();
        ctx.json(response.getBody().toString());
    }
}
