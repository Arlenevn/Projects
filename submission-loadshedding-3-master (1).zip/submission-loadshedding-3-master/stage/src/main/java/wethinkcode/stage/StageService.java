package wethinkcode.stage;


import com.google.common.annotations.VisibleForTesting;
import io.javalin.Javalin;
import io.javalin.http.Context;
import io.javalin.http.HttpStatus;
import org.apache.activemq.ActiveMQConnectionFactory;
import wethinkcode.loadshed.common.mq.MQ;
import wethinkcode.loadshed.common.transfer.StageDO;
import wethinkcode.loadshed.spikes.QueueSender;

import javax.jms.*;


/**
 * I provide a REST API that reports the current loadshedding "stage". I provide two endpoints:
 * <dl>
 * <dt>GET /stage
 * <dd>report the current stage of loadshedding as a JSON serialisation of a {@code StageDO} data/transfer object
 * <dt>POST /stage
 * <dd>set a new loadshedding stage/level by POSTing a JSON-serialised {@code StageDO} instance as the body of the
 * request.
 * </ul>
 */
public class StageService
{
    public static final int DEFAULT_STAGE = 0; // no loadshedding. Ha!

    public static final int DEFAULT_PORT = 7001;

    public static final String MQ_TOPIC_NAME = "stage";

    public static void main( String[] args ){
        final StageService svc = new StageService().initialise();
        svc.start();
    }

    private int loadSheddingStage;

    private Javalin server;

    private int servicePort;
    //create session

    @VisibleForTesting
    StageService initialise(){
        return initialise( DEFAULT_STAGE );
    }

    @VisibleForTesting
    StageService initialise( int initialStage ){
        loadSheddingStage = initialStage;
        assert loadSheddingStage >= 0;
        server = initHttpServer();
        return this;
        // intitialise mqsession
    }

    public void start(){
        start( DEFAULT_PORT );
    }

    @VisibleForTesting
    void start( int networkPort ){
        servicePort = networkPort;
        try {
            run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stop(){
        if (server != null) {
            server.stop();
        }
    }

    public void run(){
        if (server != null) {
            server.start(servicePort);
        }
    }

    private Javalin initHttpServer(){
        return Javalin.create()
                .get( "/stage", this::getCurrentStage )
                .post( "/stage", this::setNewStage );
    }

    private Context getCurrentStage( Context ctx ){
        return ctx.json( new StageDO( loadSheddingStage ) );
    }

    private Context setNewStage( Context ctx ){
        try {
            final StageDO stageData = ctx.bodyAsClass(StageDO.class);
            if (stageData != null) {
                final int newStage = stageData.getStage();
                if (newStage >= 0) {
                    loadSheddingStage = newStage;
                    broadcastStageChangeEvent(ctx);
                    ctx.status(HttpStatus.OK);
                } else {
                    ctx.status(HttpStatus.BAD_REQUEST);
                }
            } else {
                ctx.status(HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            ctx.status(HttpStatus.INTERNAL_SERVER_ERROR);
            e.printStackTrace();  // Log the exception or handle it as needed
        }
        return ctx.json(new StageDO(loadSheddingStage));
    }

    private void broadcastStageChangeEvent(Context ctx) throws JMSException {
        // Extract the stage from the incoming context
        final StageDO stageData = ctx.bodyAsClass(StageDO.class);
        final int newStage = stageData.getStage();

        // Only send a message if the newStage value is valid
        if (newStage >= 0) {
            if (isMessagingBrokerReachable()) {
                final ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(MQ.URL);
                Connection connection = factory.createConnection(MQ.USER, MQ.PASSWD);

                try {
                    connection.start();
                    Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

                    try {
                        Topic topic = session.createTopic(MQ_TOPIC_NAME);
                        MessageProducer producer = session.createProducer(topic);

                        try {
                            TextMessage textMessage = session.createTextMessage(ctx.body());
                            producer.send(textMessage);

                            // Update the loadSheddingStage value in the StageService
                            loadSheddingStage = newStage;

                            // Respond with the updated StageDO
                            ctx.json(new StageDO(loadSheddingStage));
                        } finally {
                            producer.close();
                        }
                    } finally {
                        session.close();
                    }
                } finally {
                    connection.close();
                }
            } else {
                ctx.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .result("ActiveMQ broker is not running.");
            }
        } else {
            ctx.status(HttpStatus.BAD_REQUEST);
        }
    }

    private boolean isMessagingBrokerReachable() {
        String brokerURL = "tcp://localhost:61616";

        try {
            // Attempt to create a connection to the messaging broker
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
            connectionFactory.createConnection().close(); // This line will throw an exception if the connection fails
            return true;
        } catch (Exception e) {
            // Log or print an error message
            System.err.println("Error checking messaging broker status: " + e.getMessage());
            return false;
        }
    }
}
