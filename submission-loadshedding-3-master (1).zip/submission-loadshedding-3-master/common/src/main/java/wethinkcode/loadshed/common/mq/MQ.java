package wethinkcode.loadshed.common.mq;

/**
 * I contain a few variables and definitions common to all the MQ utility classes.
 */
public interface MQ
{
    static final String URL = "tcp://localhost:61616";

    static final String USER = "admin";

    static final String PASSWD = "admin";
}
