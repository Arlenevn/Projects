package wethinkcode.loadshed.spikes;

import javax.jms.*;

import org.apache.activemq.ActiveMQConnectionFactory;
import wethinkcode.loadshed.common.mq.MQ;

import java.util.function.Consumer;

/**
 * I am a small "maker" app for receiving MQ messages from the Stage Service by
 * subscribing to a Topic.
 */
public class TopicReceiver implements Runnable
{
    private static long NAP_TIME = 2000; //ms

    public static final String MQ_TOPIC_NAME = "stage";

    private final Consumer<String> messageProcessor; // Add a field to store the message processor


    public TopicReceiver(Consumer<String> messageProcessor) {
        this.messageProcessor = messageProcessor;
    }

    public static void main( String[] args ){
        final TopicReceiver app = new TopicReceiver(message -> System.out.println("Received message: " + message));
        app.run();
    }

    private boolean running = true;

    private Connection connection;

    @Override
    public void run(){
        setUpMessageListener();
        while( running ){
            System.out.println( "Still doing stufff..." );
            snooze();
        }
        closeConnection();
        System.out.println( "Bye..." );
    }

    private void setUpMessageListener(){
        try{
            final ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory( MQ.URL );
            connection = factory.createConnection( MQ.USER, MQ.PASSWD );

            final Session session = connection.createSession( false, Session.AUTO_ACKNOWLEDGE );
            final Destination dest = session.createTopic( MQ_TOPIC_NAME ); // <-- NB: Topic, not Queue!

            final MessageConsumer receiver = session.createConsumer( dest );
            receiver.setMessageListener(m -> {
                        try {
                            if (m instanceof TextMessage) {
                                String body = ((TextMessage) m).getText();
                                if ("SHUTDOWN".equals(body)) {
                                    System.out.println("Received SHUTDOWN message. Shutting down...");
                                    connection.close();
                                    System.exit(0);
                                } else {
                                    System.out.println("Received message: " + body);
                                    messageProcessor.accept(body);
                                }
                            } else {
                                System.out.println("Unexpected message type: " + m.getClass());
                            }
                        } catch (JMSException e) {
                            e.printStackTrace();
                        }
                    }
            );
            connection.start();

        }catch( JMSException erk ){
            throw new RuntimeException( erk );
        }
    }

    private void snooze(){
        try{
            Thread.sleep( NAP_TIME );
        }catch( InterruptedException eek ){
            System.err.println("Error during snooze: " + eek.getMessage());
            eek.printStackTrace();
        }
    }

    private void closeConnection(){
        if( connection != null ) try{
            connection.close();
        }catch( JMSException ex ){
            System.err.println("Error closing connection: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
