package wethinkcode.web;

import com.google.common.annotations.VisibleForTesting;
import io.javalin.Javalin;
import io.javalin.plugin.rendering.template.JavalinThymeleaf;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import kong.unirest.json.JSONArray;
import kong.unirest.json.JSONObject;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import wethinkcode.loadshed.common.transfer.DayDO;
import wethinkcode.loadshed.common.transfer.ScheduleDO;
import wethinkcode.loadshed.common.transfer.SlotDO;
import wethinkcode.loadshed.spikes.TopicReceiver;
import wethinkcode.schedule.ScheduleService;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

public class WebService {

    public static final int DEFAULT_PORT = 8080;
    private static final String TEMPLATES_DIR = "/templates/";

    private Javalin server;
    private int servicePort;
    private int loadSheddingStage = 0;

    public static void main(String[] args) {
        JavalinThymeleaf.configure(templateEngine());
        ApiService apiService = new ApiService();
        final WebService svc = new WebService().initialise(args);
        svc.start();
    }

    @VisibleForTesting
    private WebService initialise(String[] args) {
        server = configureHttpServer();
        TopicReceiver receiver = new TopicReceiver(this::processMessage);
        Thread threadReceiver = new Thread(receiver);
        threadReceiver.start();
        return this;
    }

    private void processMessage(String message) {
        try {
            JSONObject json = new JSONObject(message);

            // Retrieve the integer value associated with the "stage" key
            int newStage = json.getInt("stage");
            setLoadSheddingStage(newStage);
        } catch (NumberFormatException e) {
            System.err.println("Invalid stage format: " + message);
        }
    }

    private void setLoadSheddingStage(int newStage) {
        this.loadSheddingStage = newStage;
    }

    public void start() {
        start(DEFAULT_PORT);
    }

    private void start(int networkPort) {
        servicePort = networkPort;
        run();
    }

    public void stop() {
        server.stop();
    }

    private void run() {
        server.start(servicePort);
    }

    private Javalin configureHttpServer() {
        Javalin createApp = Javalin.create();

        AtomicReference<String> Selected_Province = new AtomicReference<>("");
        AtomicReference<String> Selected_Town = new AtomicReference<>("");

        createApp.get("/", ctx -> {
            // Check if the request contains the chosen province param
            String inputProvince = ctx.queryParam("province");
            String inputTown = ctx.queryParam("town");

            if (inputProvince != null) {
                Selected_Province.set(inputProvince);
            }
            if (inputTown != null) {
                Selected_Town.set(inputTown);
            }
            // Fetch towns for the selected province (default to empty array)
            JSONArray towns = new JSONArray();
            List<String> townsList = new ArrayList<>();
            if (inputProvince != null && !inputProvince.isEmpty()) {
                // Handle selected province
                HttpResponse<JsonNode> town = Unirest.get("http://localhost:7000/towns/" + inputProvince).asJson();
                towns = town.getBody().getArray();
                for (int i = 0; i < towns.length(); i++) {
                    JSONObject jsonObject = towns.getJSONObject(i);
                    String name = jsonObject.getString("name");
                    townsList.add(name);
                }
            }

            // Make HTTP GET request to server and retrieve data
            HttpResponse<JsonNode> response = Unirest.get("http://localhost:7000/provinces").asJson();
            // Extract data
            JSONArray provinces = response.getBody().getArray();
            int stage;

            if (loadSheddingStage != 0) {
                stage = loadSheddingStage;
            } else {
                HttpResponse<JsonNode> getStage = Unirest.get("http://localhost:7001" + "/stage").asJson();
                stage = getStage.getBody().getObject().getInt("stage");
            }

            // Create data model and pass it to the template
            Map<String, Object> viewModel;
            if (towns.isEmpty()) {
                viewModel = Map.of("provinces", provinces, "stage", stage);
            } else {
                viewModel = Map.of("provinces", provinces, "stage", stage, "towns", townsList);
            }

            // Server index page to the client
            String homePage = "index.html";
            ctx.render("index.html", viewModel);

        });

        createApp.post("/schedule", ctx -> {
            ScheduleService scheduleDO = new ScheduleService();

            // handle submission and fetch schedule data
            int stage;

            if (loadSheddingStage != 0) {
                stage = loadSheddingStage;
            } else {
                HttpResponse<JsonNode> getStage = Unirest.get("http://localhost:7001" + "/stage").asJson();
                stage = getStage.getBody().getObject().getInt("stage");
            }


            final Optional<ScheduleDO> schedule = scheduleDO.getSchedule(String.valueOf(Selected_Province), String.valueOf(Selected_Town), stage );
            List<String> scheduleList;
            if (!schedule.get().getDays().isEmpty()) {
                List<DayDO> day = schedule.get().getDays();
                scheduleList = createSchedule(schedule, day);
            } else {
                scheduleList = new ArrayList<>();
            }

            Map<String, Object> viewModel = Map.of("schedule", scheduleList,
                    "stage", stage);
            // fetch schedule data
            //display on page
            String schedulePage = "schedule.html";
            ctx.render(schedulePage, viewModel);
        } );

        return createApp;
    }

    public static List<String> createSchedule(Optional<ScheduleDO> schedule, List<DayDO> days) {
        List<String> scheduleList = new ArrayList<>();
        for (int i = 0; i < schedule.get().numberOfDays(); i++) {
            DayDO currentDay = days.get(i);
            LocalDate currentDate = schedule.get().getStartDate().plusDays(i);
            DayOfWeek dayOfWeek = currentDate.getDayOfWeek();
            Month monthOfYear = currentDate.getMonth();
            int dayOfMonth = currentDate.getDayOfMonth();

            StringBuilder dayInfo = new StringBuilder();
            dayInfo.append("Day: ")
                    .append(dayOfWeek)
                    .append(" ")
                    .append(monthOfYear)
                    .append(" ")
                    .append(dayOfMonth);

            scheduleList.add(dayInfo.toString());

            for (SlotDO slot : currentDay.getSlots()) {
                StringBuilder slotInfo = new StringBuilder();
                slotInfo.append("Start Time: ").append(slot.getStart());
                slotInfo.append("\nEnd Time: ").append(slot.getEnd());
                scheduleList.add(slotInfo.toString());
            }
        }
        return scheduleList;
    }


    private static TemplateEngine templateEngine() {
        TemplateEngine templateEngine = new TemplateEngine();
        ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
        resolver.setPrefix(TEMPLATES_DIR);
        templateEngine.setTemplateResolver(resolver);
        return templateEngine;
    }
}
