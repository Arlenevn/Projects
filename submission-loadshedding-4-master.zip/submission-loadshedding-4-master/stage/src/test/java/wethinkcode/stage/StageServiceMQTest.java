package wethinkcode.stage;


import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;

import javax.jms.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kong.unirest.HttpResponse;
import kong.unirest.HttpStatus;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.junit.jupiter.api.*;
import wethinkcode.loadshed.common.mq.MQ;
import wethinkcode.loadshed.common.transfer.StageDO;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * I test StageService message sending.
 */
@Disabled
@Tag( "expensive" )
public class StageServiceMQTest
{
    public static final int TEST_PORT = 7777;

    private static StageService server;

    private static ActiveMQConnectionFactory factory;

    private static Connection mqConnection;
    private static MessageConsumer receiver;

    @BeforeAll
    public static void startInfrastructure() throws JMSException {
        startMsgQueue();
        startStageSvc();
    }

    @AfterAll
    public static void cleanup() throws JMSException {
        server.stop();
        mqConnection.close();
    }

    @BeforeEach
    public void connectMqListener() throws JMSException {
        mqConnection = factory.createConnection(MQ.USER, MQ.PASSWD);
        final Session session = mqConnection.createSession( false, Session.AUTO_ACKNOWLEDGE );
        final Destination dest = session.createTopic( StageService.MQ_TOPIC_NAME );

        receiver = session.createConsumer( dest );
//        receiver.setMessageListener( listener );

        mqConnection.start();
    }

    @AfterEach
    public void closeMqConnection() throws JMSException {
        mqConnection.close();
//        mqConnection = null;
    }

    @Test
    public void sendMqEventWhenStageChanges() throws InterruptedException, JMSException {
        // Set up a SynchronousQueue to catch the result
        final SynchronousQueue<StageDO> resultCatcher = new SynchronousQueue<>();

        // Create a MessageListener that puts the received StageDO into the resultCatcher
        final MessageListener mqListener = message -> {
            try {
                if (message instanceof TextMessage) {
                    String json = ((TextMessage) message).getText();
                    StageDO receivedStage = new ObjectMapper().readValue(json, StageDO.class);
                    resultCatcher.put(receivedStage);
                } else {
                    fail("Received message is not of expected type TextMessage.");
                }
            } catch (JMSException | IOException | InterruptedException e) {
                fail("Failed to process the received message.");
            }
        };
        receiver.setMessageListener(mqListener);

        // Get the initial stage
        HttpResponse<StageDO> startStage = Unirest.get(serverUrl() + "/stage").asObject(StageDO.class);
        assertEquals(HttpStatus.OK, startStage.getStatus());
        StageDO initialStage = startStage.getBody();

        // Change the stage
        int newStageValue = initialStage.getStage() + 1;
        HttpResponse<JsonNode> changeStage = Unirest.post(serverUrl() + "/stage")
                .header("Content-Type", "application/json")
                .body(new StageDO(newStageValue))
                .asJson();
        assertEquals(HttpStatus.OK, changeStage.getStatus());

        // Wait for the message to be received by the listener
        StageDO receivedStage = resultCatcher.take();

        // Assert that the received stage is not null and has the expected value
        assertNotNull(receivedStage);
        assertEquals(newStageValue, receivedStage.getStage());


    }

    private static void startMsgQueue() throws JMSException {
        factory = new ActiveMQConnectionFactory(MQ.URL);
    }

    private static void startStageSvc(){
        server = new StageService().initialise();
        server.start( TEST_PORT );
    }

    private String serverUrl(){
        return "http://localhost:" + TEST_PORT;
    }
}
