package za.co.wethinkcode.fizzbuzz;
import java.util.ArrayList;
import java.util.List;
public class FizzBuzz {
    public String checkNumber(int number) {
        boolean divisibleBy3 = number % 3 == 0;
        boolean divisibleBy5 = number % 5 == 0;

        if (divisibleBy3 && divisibleBy5) {
            return "FizzBuzz";
        } else if (divisibleBy3) {
            return "Fizz";
        } else if (divisibleBy5) {
            return "Buzz";
        } else {
            return String.valueOf(number);
        }
    }

    public String countTo(int number) {
        List<String> fizzBuzzList = new ArrayList<>();
        for (int x = 1; x <= number; x++) {

            if ((x % 3 == 0) && (x % 5 == 0)) {
                fizzBuzzList.add("FizzBuzz");
            } else if (x % 3 == 0) {
                fizzBuzzList.add("Fizz");
            } else if (x % 5 == 0) {
                fizzBuzzList.add("Buzz");
            } else {
                fizzBuzzList.add(String.valueOf(x));
            }
        }
        return fizzBuzzList.toString();
    }
}

